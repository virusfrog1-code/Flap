import AccessGate from "../components/AccessGate.jsx";
import DynamicNFAArt from "../components/DynamicNFAArt.jsx";
import SectionTitle from "../components/SectionTitle.jsx";
import { myNfas, walletMock } from "../data/mock.js";

export default function MyNFA({ onNavigate, t }) {
  return (
    <section className="shell section-block">
      <SectionTitle
        eyebrow={t.myNfa.eyebrow}
        title={t.myNfa.title}
        copy={t.myNfa.copy}
      />

      <div className="dashboard-grid">
        <AccessGate
          title={t.myNfa.walletSummary}
          checks={t.myNfa.checks}
          eyebrow={t.vpn.gateTitle}
        >
          <div className="wallet-summary">
            <span>{t.myNfa.wallet}</span>
            <strong>{walletMock.address}</strong>
            <span>{t.myNfa.network}</span>
            <strong>{walletMock.network}</strong>
            <span>{t.myNfa.holderStatus}</span>
            <strong>{t.common.verified}</strong>
          </div>
        </AccessGate>

        <div className="benefits-panel glass-panel">
          <h3>{t.myNfa.benefits}</h3>
          <div className="benefit-list">
            {t.myNfa.benefitsList.map((benefit) => (
              <span key={benefit}>{benefit}</span>
            ))}
          </div>
          <button className="primary-button full" type="button" onClick={() => onNavigate("vpn")}>
            {t.myNfa.openVpn}
          </button>
          <button className="secondary-button full" type="button" onClick={() => onNavigate("agent")}>
            {t.myNfa.openAgent}
          </button>
        </div>
      </div>

      <div className="my-nfa-grid">
        {myNfas.map((item) => (
          <article className="holder-card" key={item.tokenId}>
            <DynamicNFAArt item={item} large />
            <div>
              <h3>{item.collectionName || "财翼 NFA"} #{item.tokenId}</h3>
              <p>{t.myNfa.vpnStatus}: {t.common.active}</p>
              <p>{t.myNfa.agentAccess}: {t.common.enabled}</p>
              <p>{t.myNfa.marketplaceStatus}: {item.listed ? t.common.listed : t.common.vault}</p>
              <button className="secondary-button full" type="button" onClick={() => onNavigate("marketplace")}>
                {t.myNfa.listOnMarket}
              </button>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
