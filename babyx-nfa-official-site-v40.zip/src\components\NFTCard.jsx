﻿import DynamicNFAArt from "./DynamicNFAArt.jsx";

const shortAddress = (address) => `${address.slice(0, 6)}...${address.slice(-4)}`;
const formatAmount = (amount) => Number(amount || 0).toLocaleString("en-US");

export default function NFTCard({ item, onSelect, labels }) {
  const text = {
    listed: "Listed",
    vault: "Vault",
    vpnAccess: "VPN Access",
    vpnPending: "VPN Pending",
    buy: "Buy",
    view: "View",
    makeOffer: "Offer",
    suggestedAsk: "Suggested",
    ...labels,
  };
  const profile = item.dynamicProfile;
  const displayPrice = item.listed ? formatAmount(item.price) : formatAmount(item.suggestedAsk);

  return (
    <article className="nft-card" onClick={() => onSelect?.(item)}>
      <button type="button" aria-label={`View 财翼 NFA #${item.tokenId}`}>
        <DynamicNFAArt item={item} />
        <span className={`listing-badge ${item.listed ? "listed" : "vault"}`}>
          {item.listed ? text.listed : text.vault}
        </span>
      </button>
      <div className="nft-card-body">
        <div>
          <h3>{item.collectionName || "财翼 NFA"} #{item.tokenId}</h3>
          <p>{profile?.rarity || "Dynamic"} / {profile?.wing || "Space Wing"}</p>
        </div>
        <strong>
          {item.listed ? displayPrice : `${text.suggestedAsk} ${displayPrice}`} {item.tokenSymbol || "财翼"}
        </strong>
      </div>
      <div className="trait-strip">
        <span>{profile?.orbit || "Orbit"}</span>
        <span>Signal {profile?.signal || "--"}</span>
        <span>{profile?.state || "Live"}</span>
      </div>
      <div className="nft-meta-row">
        <span>{item.vpnAccess ? text.vpnAccess : text.vpnPending} / {shortAddress(item.owner)}</span>
        <div>
          <button className="mini-button primary" type="button" onClick={(event) => event.stopPropagation()}>
            {item.listed ? text.buy : text.makeOffer}
          </button>
          <button className="mini-button" type="button" onClick={(event) => event.stopPropagation()}>
            {text.view}
          </button>
        </div>
      </div>
    </article>
  );
}
