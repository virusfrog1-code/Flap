import HeroBabyX from "../components/HeroBabyX.jsx";
import SectionTitle from "../components/SectionTitle.jsx";

export default function SchemaDeploy({ t }) {
  return (
    <section className="shell section-block">
      <SectionTitle
        eyebrow={t.schema.eyebrow}
        title={t.schema.title}
        copy={t.schema.copy}
      />
      <div className="page-grid two-col schema-layout">
        <HeroBabyX compact />
        <article className="glass-panel schema-card">
          <h3>{t.schema.cardTitle}</h3>
          <p>
            {t.schema.cardCopy}
          </p>
          <a className="primary-button link-button" href="/deploy-image-schema.html?exact=v12">
            {t.schema.open}
          </a>
          <div className="resource-list">
            <span>/assets/babyx-nfa-butterfly-space-animated.svg</span>
            <span>/assets/babyx-nfa-butterfly-space-960.jpg</span>
            <span>/artifacts/BabyXNFAImageSchema.json</span>
          </div>
        </article>
      </div>
    </section>
  );
}
