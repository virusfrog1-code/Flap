import { useEffect, useMemo, useState } from "react";
import Navbar from "./components/Navbar.jsx";
import Home from "./pages/Home.jsx";
import Mint from "./pages/Mint.jsx";
import Marketplace from "./pages/Marketplace.jsx";
import MyNFA from "./pages/MyNFA.jsx";
import VPN from "./pages/VPN.jsx";
import AIAgent from "./pages/AIAgent.jsx";
import SchemaDeploy from "./pages/SchemaDeploy.jsx";
import { translations } from "./data/i18n.js";

const pages = {
  home: Home,
  mint: Mint,
  marketplace: Marketplace,
  vpn: VPN,
  agent: AIAgent,
  "my-nfa": MyNFA,
  schema: SchemaDeploy,
};

export default function App() {
  const [activePage, setActivePage] = useState("home");
  const [language, setLanguage] = useState(() => localStorage.getItem("babyx-language") || "en");
  const Page = useMemo(() => pages[activePage] || Home, [activePage]);
  const t = translations[language] || translations.en;

  useEffect(() => {
    localStorage.setItem("babyx-language", language);
    document.documentElement.lang = language;
  }, [language]);

  return (
    <div className="app">
      <div className="space-bg" />
      <Navbar activePage={activePage} onNavigate={setActivePage} language={language} onLanguageChange={setLanguage} t={t} />
      <main>
        <Page onNavigate={setActivePage} t={t} language={language} />
      </main>
    </div>
  );
}
