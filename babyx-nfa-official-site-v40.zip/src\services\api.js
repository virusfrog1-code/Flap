import {
  agentActivity,
  agentStrategies,
  agentVaultMock,
  externalFlapMarketplaceItems,
  flapIntegratedCollections,
  flapTaxInfo,
  flapVaultManual,
  marketplaceItems,
  vpnDevices,
  vpnMockStatus,
  walletMock,
} from "../data/mock.js";

const wait = (ms = 420) => new Promise((resolve) => setTimeout(resolve, ms));

export async function getMarketplaceListings() {
  await wait();
  return [...marketplaceItems, ...externalFlapMarketplaceItems];
}

export async function getFlapTaxInfo() {
  await wait();
  return {
    endpoint: "/api/flap/taxinfo?token=0xe1734a27f06f1189b0f65ae3b68fc010d4717777",
    ...flapTaxInfo,
  };
}

export async function getFlapCollections() {
  await wait();
  return {
    endpoint: "/api/flap/collections",
    collections: flapIntegratedCollections,
  };
}

function readPageTitle(html) {
  const match = html.match(/<title[^>]*>(.*?)<\/title>/is);
  return match ? match[1].replace(/\s+/g, " ").trim() : flapVaultManual.title;
}

function includesAny(text, terms) {
  const lower = text.toLowerCase();
  return terms.some((term) => lower.includes(term.toLowerCase()));
}

export async function getFlapVaultManual() {
  const source = flapVaultManual.source;
  try {
    const response = await fetch(source, { cache: "no-store" });
    if (!response.ok) throw new Error(`Flap vault doc returned ${response.status}`);
    const html = await response.text();
    const text = html.replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<[^>]+>/g, " ");
    const compact = text.replace(/\s+/g, " ").trim();
    return {
      ...flapVaultManual,
      endpoint: "/api/flap/vault-manual/live",
      status: "live",
      title: readPageTitle(html),
      fetchedAt: new Date().toISOString(),
      byteLength: html.length,
      mechanics: [
        {
          label: "Token -> NFT",
          value: includesAny(compact, ["tokenAmount", "mint", "兑换", "合成"]) ? "Detected tokenAmount / NFT redemption flow" : flapVaultManual.mechanics[0].value,
        },
        {
          label: "Dividend",
          value: includesAny(compact, ["claim", "dividend", "分红"]) ? "Detected claim() / dividend pool wording" : flapVaultManual.mechanics[1].value,
        },
        {
          label: "Floor Exit",
          value: includesAny(compact, ["sellToVault", "floor", "地板价"]) ? "Detected sellToVault / floor pool wording" : flapVaultManual.mechanics[2].value,
        },
        {
          label: "Live Source",
          value: source,
        },
      ],
    };
  } catch (error) {
    return {
      ...flapVaultManual,
      endpoint: "/api/flap/vault-manual/fallback",
      status: "fallback",
      fetchedAt: new Date().toISOString(),
      error: error instanceof Error ? error.message : "Unable to fetch Flap vault documentation",
    };
  }
}

export async function syncFlapCollection(collectionId) {
  await wait(680);
  return {
    endpoint: "/api/flap/collections/sync",
    status: "mock-synced",
    collectionId,
    syncedAt: new Date().toISOString(),
  };
}

export async function createMarketplaceListing({ tokenId, price }) {
  await wait();
  return {
    endpoint: "/api/marketplace/list",
    status: "mock-listed",
    tokenId,
    price: Number(price),
  };
}

export async function cancelMarketplaceListing({ tokenId }) {
  await wait();
  return {
    endpoint: "/api/marketplace/cancel",
    status: "mock-cancelled",
    tokenId,
  };
}

export async function buyMarketplaceItem({ tokenId, price }) {
  await wait(650);
  return {
    endpoint: "/api/marketplace/buy",
    status: "mock-purchased",
    tokenId,
    price: Number(price),
  };
}

export async function placeMarketplaceBid({ tokenId, amount }) {
  await wait();
  return {
    endpoint: "/api/marketplace/bid",
    status: "mock-bid-placed",
    tokenId,
    amount: Number(amount),
    bidId: `bid-${tokenId}-user-${Date.now()}`,
  };
}

export async function acceptMarketplaceBid({ tokenId, bidId }) {
  await wait();
  return {
    endpoint: "/api/marketplace/accept-bid",
    status: "mock-bid-accepted",
    tokenId,
    bidId,
  };
}

export async function prepareMint({ quantity = 1 } = {}) {
  await wait();
  return {
    endpoint: "/api/mint/prepare",
    quantity,
    pricePerNfa: 0.12,
    totalPrice: Number((quantity * 0.12).toFixed(2)),
    walletRequired: true,
  };
}

export async function confirmMint({ quantity = 1 } = {}) {
  await wait(720);
  return {
    endpoint: "/api/mint/confirm",
    status: "success",
    tokenId: 200 + quantity,
    transactionLabel: "mock-confirmed",
  };
}

export async function getVpnStatus(wallet) {
  await wait();
  return {
    endpoint: `/api/vpn/status?wallet=${encodeURIComponent(wallet || walletMock.address)}`,
    ...vpnMockStatus,
    devices: vpnDevices,
  };
}

export async function verifyVpnHolder(wallet) {
  await wait();
  return {
    endpoint: "/api/vpn/verify-holder",
    wallet: wallet || walletMock.address,
    isHolder: walletMock.isHolder,
    tokenIds: walletMock.verifiedNfas,
  };
}

export async function issueVpnSubscription(wallet) {
  await wait();
  return {
    endpoint: "/api/vpn/issue-subscription",
    wallet: wallet || walletMock.address,
    subscriptionUrl: vpnMockStatus.subscriptionUrl,
    tokenStatus: "issued-by-backend",
    expiresIn: vpnMockStatus.expiresIn,
  };
}

export async function revokeVpnDevice(deviceId) {
  await wait();
  return {
    endpoint: "/api/vpn/revoke-device",
    status: "mock-revoked",
    deviceId,
  };
}

export async function getAgentVault(wallet) {
  await wait();
  return {
    endpoint: `/api/agent/vault?wallet=${encodeURIComponent(wallet || walletMock.address)}`,
    ...agentVaultMock,
    strategies: agentStrategies,
    activity: agentActivity,
  };
}

export async function depositAgentFunds({ amount, strategy }) {
  await wait(760);
  return {
    endpoint: "/api/agent/vault/deposit",
    status: "mock-deposited",
    amount: Number(amount),
    strategy,
  };
}

export async function withdrawAgentFunds({ amount }) {
  await wait(650);
  return {
    endpoint: "/api/agent/vault/withdraw",
    status: "mock-withdraw-requested",
    amount: Number(amount),
  };
}

export async function startAgentStrategy({ strategyId, allocation }) {
  await wait();
  return {
    endpoint: "/api/agent/strategy/start",
    status: "mock-strategy-started",
    strategyId,
    allocation: Number(allocation),
  };
}

export async function sendAgentMessage(message, wallet) {
  await wait(680);
  return {
    endpoint: "/api/agent/chat",
    wallet: wallet || walletMock.address,
    message,
    reply:
      "财翼 Agent mock response: vault actions, strategy execution, VPN access and NFT marketplace orders will be connected to backend APIs.",
  };
}

export async function getAgentAccess(wallet) {
  await wait();
  return {
    endpoint: `/api/agent/access?wallet=${encodeURIComponent(wallet || walletMock.address)}`,
    isHolder: walletMock.isHolder,
    access: walletMock.isHolder,
  };
}
