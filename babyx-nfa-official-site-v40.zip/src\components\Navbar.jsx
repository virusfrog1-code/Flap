import { useState } from "react";
import LanguageSwitcher from "./LanguageSwitcher.jsx";
import WalletButton from "./WalletButton.jsx";

const navItems = [
  { id: "home", labelKey: "home" },
  { id: "mint", labelKey: "mint" },
  { id: "marketplace", labelKey: "marketplace" },
  { id: "vpn", labelKey: "vpn" },
  { id: "agent", labelKey: "agent" },
  { id: "my-nfa", labelKey: "myNfa" },
  { id: "schema", labelKey: "schema" },
];

function MenuIcon() {
  return (
    <>
      <span />
      <span />
      <span />
    </>
  );
}

export default function Navbar({ activePage, onNavigate, language, onLanguageChange, t }) {
  const [open, setOpen] = useState(false);

  const navigate = (page) => {
    onNavigate(page);
    setOpen(false);
  };

  return (
    <header className="navbar shell">
      <button className="brand" type="button" onClick={() => navigate("home")} aria-label={`${t.nav.brandName} home`}>
        <span className="brand-mark">{t.nav.brandMark}</span>
        <span>
          <strong>{t.nav.brandName}</strong>
          <small>{t.nav.brandSubtitle}</small>
        </span>
      </button>

      <button
        className="mobile-menu-button"
        type="button"
        aria-label={t.nav.toggle}
        aria-expanded={open}
        onClick={() => setOpen((value) => !value)}
      >
        <MenuIcon />
      </button>

      <nav className={`nav-links ${open ? "is-open" : ""}`}>
        {navItems.map((item) => (
          <button
            key={item.id}
            className={activePage === item.id ? "active" : ""}
            type="button"
            onClick={() => navigate(item.id)}
          >
            {t.nav[item.labelKey]}
          </button>
        ))}
      </nav>

      <div className="nav-actions">
        <LanguageSwitcher language={language} onLanguageChange={onLanguageChange} label={t.common.language} />
        <WalletButton label={t.common.connectWallet} />
        <button
          className="nav-toggle"
          type="button"
          aria-label={t.nav.toggle}
          aria-expanded={open}
          onClick={() => setOpen((value) => !value)}
        >
          <MenuIcon />
        </button>
      </div>
    </header>
  );
}
