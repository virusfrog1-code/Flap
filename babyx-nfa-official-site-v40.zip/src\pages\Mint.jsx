import { useState } from "react";
import HeroBabyX from "../components/HeroBabyX.jsx";
import SectionTitle from "../components/SectionTitle.jsx";
import { FLAP_LINKS } from "../data/mock.js";

export default function Mint({ onNavigate, t }) {
  const [copied, setCopied] = useState(false);

  const copyProjectToken = async () => {
    await navigator.clipboard?.writeText(FLAP_LINKS.projectToken);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1600);
  };

  return (
    <section className="shell section-block">
      <SectionTitle
        eyebrow={t.mint.eyebrow}
        title={t.mint.title}
        copy={t.mint.copy}
      />

      <div className="page-grid two-col mint-layout">
        <HeroBabyX compact />

        <aside className="glass-panel mint-panel flap-mint-panel">
          <div className="panel-header">
            <span className="eyebrow">{t.mint.route}</span>
            <h2>{t.mint.routeTitle}</h2>
            <p>{t.mint.routeCopy}</p>
          </div>

          <div className="flap-detail-grid">
            <article>
              <span>{t.mint.platform}</span>
              <strong>Flap Official</strong>
            </article>
            <article>
              <span>{t.mint.network}</span>
              <strong>BNB Smart Chain</strong>
            </article>
            <article>
              <span>{t.mint.supply}</span>
              <strong>{t.mint.supplyValue}</strong>
            </article>
          </div>

          <div className="flap-flow">
            {t.mint.steps.map(([title, copy], index) => (
              <article key={title}>
                <span>{index + 1}</span>
                <strong>{title}</strong>
                <p>{copy}</p>
              </article>
            ))}
          </div>

          <div className="flap-address">
            <span>{t.mint.projectToken}</span>
            <code>{FLAP_LINKS.projectToken}</code>
            <button className="mini-button primary" type="button" onClick={copyProjectToken}>
              {copied ? t.common.copied : "Copy"}
            </button>
          </div>

          <div className="button-row">
            <a className="primary-button" href={FLAP_LINKS.bnbApp} target="_blank" rel="noreferrer">
              {t.mint.openFlap}
            </a>
            <a className="secondary-button blue" href={FLAP_LINKS.official} target="_blank" rel="noreferrer">
              {t.mint.official}
            </a>
            <button className="secondary-button" type="button" onClick={() => onNavigate("schema")}>
              {t.mint.schema}
            </button>
          </div>

          <article className="external-note">{t.mint.note}</article>
        </aside>
      </div>
    </section>
  );
}
