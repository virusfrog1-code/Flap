import { languageOptions } from "../data/i18n.js";

export default function LanguageSwitcher({ language, onLanguageChange, label }) {
  return (
    <label className="language-switcher">
      <span>{label}</span>
      <select value={language} onChange={(event) => onLanguageChange(event.target.value)}>
        {languageOptions.map((option) => (
          <option value={option.code} key={option.code}>
            {option.short} - {option.label}
          </option>
        ))}
      </select>
    </label>
  );
}
