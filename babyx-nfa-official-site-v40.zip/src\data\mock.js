﻿export const BABYX_ASSETS = {
  animated: "/assets/babyx-nfa-butterfly-space-animated.svg",
  poster: "/assets/babyx-nfa-butterfly-space-960.jpg",
};

export const walletMock = {
  address: "0xB4bY...9F12",
  connected: true,
  isHolder: true,
  network: "BNB Smart Chain",
  verifiedNfas: [108, 132, 178],
};

export const FLAP_LINKS = {
  official: "https://flap.sh/",
  bnbApp: "https://bnb.flap.sh/board",
  projectToken: "0xe1734a27f06f1189b0f65ae3b68fc010d4717777",
  taxInfo: "https://flap.sh/bnb/0xe1734a27f06f1189b0f65ae3b68fc010d4717777/taxinfo",
  schemaDeployPath: "/deploy-image-schema.html?exact=v12",
};

export const flapTaxInfo = {
  title: "FLAPixel NFT vault",
  tokenAddress: "0xe1734a27f06f1189b0f65ae3b68fc010d4717777",
  vaultAddress: "0xd9f4...71f8",
  nftContract: "0xdf9f...0f88",
  minted: 20,
  totalSupply: 666,
  mintPercent: "3.00%",
  redeemCost: 10000,
  redeemCostLabel: "10.00K 财翼 / NFT",
  dividendRatio: "100%",
  dividendTax: "100%",
  floorTax: "0%",
  floorPoolBnb: "0 BNB",
  myClaimedBnb: "0.004744 BNB",
  pendingBnb: "0 BNB",
  ownedNfts: 20,
  totalReceivedToken: "200.00K 财翼",
  redeemedNfts: 0,
  source: FLAP_LINKS.taxInfo,
};

export const platformStats = [
  { label: "Flap Supply", value: "666", delta: "Dynamic NFA collection" },
  { label: "Unique Traits", value: "12+", delta: "Per-token metadata layers" },
  { label: "Trade Unit", value: "财翼", delta: "Mock token settlement" },
  { label: "VPN Holders", value: "312", delta: "Holder utilities enabled" },
  { label: "AI Routes", value: "4", delta: "Agent orchestration modules" },
];

export const flapIntegratedCollections = [
  {
    id: "caiwing-nfa",
    name: "财翼 NFA",
    platform: "Flap",
    contract: "0xdf9f...0f88",
    token: "财翼",
    supply: 666,
    minted: 20,
    settlement: "财翼 escrow",
    enabled: true,
    notes: "Primary 财翼 dynamic NFA collection. Mint remains on Flap; utility and orders route through 财翼.",
  },
  {
    id: "flapixel-vault",
    name: "FLAPixel NFT Vault",
    platform: "Flap",
    contract: "0xf1ap...px11",
    token: "财翼",
    supply: 333,
    minted: 88,
    settlement: "财翼 escrow",
    enabled: true,
    notes: "Mock imported Flap collection using the same bid, ask, accept, and settlement adapter.",
  },
  {
    id: "flap-asteroid",
    name: "Flap Asteroid Pass",
    platform: "Flap",
    contract: "0xa5tr...01d2",
    token: "财翼",
    supply: 512,
    minted: 127,
    settlement: "财翼 escrow",
    enabled: true,
    notes: "Example external Flap NFT collection ready for cross-collection trading UX.",
  },
];

export const utilities = [
  {
    title: "Dynamic NFT Identity",
    tag: "NFA PASS",
    description: "Animated 财翼 identity with schema-ready marketplace display and utility metadata.",
  },
  {
    title: "Free VPN for Holders",
    tag: "HOLDER VPN",
    description: "Holder verification unlocks backend-issued VPN subscription access.",
  },
  {
    title: "Clash One-click Import",
    tag: "CLASH",
    description: "Copy or import a masked subscription URL without exposing node configuration.",
  },
  {
    title: "AI Agent Access",
    tag: "AGENT",
    description: "NFA holders unlock Web3 research, utility guidance, and security assistant workflows.",
  },
];

export const collectionMechanics = [
  {
    title: "Flap Launch Layer",
    tag: "MINT",
    description: "财翼 NFA minting stays on Flap. The official site routes users to Flap and becomes the utility operating system after mint.",
  },
  {
    title: "Dynamic Trait Engine",
    tag: "NFA STATE",
    description: "Each of the 666 NFAs receives token-specific traits: wing spectrum, signal strength, orbit class, utility tier, and evolution state.",
  },
  {
    title: "Holder Access Graph",
    tag: "UTILITY",
    description: "Wallet verification maps owned NFAs into VPN access, Clash subscription status, AI Agent permissions, and market controls.",
  },
  {
    title: "Agent Orchestration",
    tag: "AI",
    description: "AI modules coordinate research, VPN support, NFT order actions, and mock strategy queues without exposing keys or backend secrets.",
  },
];

const rawMarketplaceItems = [
  {
    tokenId: 101,
    price: 0.18,
    owner: "0xA18c9e84B23A663FbF01dB4dD18e6325aF61B01C",
    listed: false,
    vpnAccess: true,
    mine: false,
    floorDelta: "-4.8%",
    highestBid: 0.16,
    bids: [
      { id: "bid-101-1", bidder: "0x736A0a6330b23F48e2B012DA1980553B27F0e706", amount: 0.16, expires: "11h" },
      { id: "bid-101-2", bidder: "0x2B9E1687b6dB28905988501A108D6C2C322FdB33", amount: 0.145, expires: "1d" },
    ],
  },
  {
    tokenId: 108,
    price: 0.21,
    owner: "0xB4bY7dEF3a991C0b2F9614A0F0c8c2B8bCC09F12",
    listed: false,
    vpnAccess: true,
    mine: true,
    floorDelta: "+2.1%",
    highestBid: 0.19,
    bids: [{ id: "bid-108-1", bidder: "0x35d967A706EB4E93a1B100F5cE0F7906b30a3E55", amount: 0.19, expires: "9h" }],
  },
  {
    tokenId: 117,
    price: 0.24,
    owner: "0x4Af1bd4aE92C0a66408b71C1fBdE8a0A36B81062",
    listed: false,
    vpnAccess: true,
    mine: false,
    floorDelta: "+5.6%",
    highestBid: 0.2,
    bids: [{ id: "bid-117-1", bidder: "0xE3A6f8A0A173725903950F6D4A2a530dcA4fb381", amount: 0.2, expires: "2d" }],
  },
  {
    tokenId: 124,
    price: 0.31,
    owner: "0x7B502BdcEf6618D4516a5f9AE1c77eF933409931",
    listed: false,
    vpnAccess: true,
    mine: false,
    floorDelta: "Vault",
    highestBid: 0.23,
    bids: [{ id: "bid-124-1", bidder: "0x9bE01C5F582447DbaC20C871308b0066f24c95AA", amount: 0.23, expires: "4h" }],
  },
  {
    tokenId: 132,
    price: 0.27,
    owner: "0xB4bY7dEF3a991C0b2F9614A0F0c8c2B8bCC09F12",
    listed: false,
    vpnAccess: true,
    mine: true,
    floorDelta: "+8.2%",
    highestBid: 0.24,
    bids: [
      { id: "bid-132-1", bidder: "0xc4EC6B4E634b352F64Fc34d9B738B2A356F6e280", amount: 0.24, expires: "6h" },
      { id: "bid-132-2", bidder: "0x03E62893012B9eC47CC68BB7CFfF64c39Cb00801", amount: 0.22, expires: "12h" },
    ],
  },
  {
    tokenId: 149,
    price: 0.36,
    owner: "0x8FD390A176A201b82075A8E7327a38F50801672D",
    listed: false,
    vpnAccess: false,
    mine: false,
    floorDelta: "+16.1%",
    highestBid: 0.3,
    bids: [{ id: "bid-149-1", bidder: "0x49A6E3c78f5570916e7217cB69B016Bd616Eba72", amount: 0.3, expires: "18h" }],
  },
  {
    tokenId: 156,
    price: 0.41,
    owner: "0x6E645d9A4E8f95f2bA1FeC88b906D77F225B2018",
    listed: false,
    vpnAccess: true,
    mine: false,
    floorDelta: "+22.9%",
    highestBid: 0.33,
    bids: [{ id: "bid-156-1", bidder: "0x39f2055834FD10B39772e720cFF9432872B82F18", amount: 0.33, expires: "3d" }],
  },
  {
    tokenId: 163,
    price: 0.46,
    owner: "0x99C282197E3b84E66Cb76a1f52a6800dF2711522",
    listed: false,
    vpnAccess: true,
    mine: false,
    floorDelta: "Vault",
    highestBid: 0.36,
    bids: [{ id: "bid-163-1", bidder: "0x725Cda55940F8f13F2090975331EF0176b123C23", amount: 0.36, expires: "1d" }],
  },
  {
    tokenId: 178,
    price: 0.52,
    owner: "0xB4bY7dEF3a991C0b2F9614A0F0c8c2B8bCC09F12",
    listed: false,
    vpnAccess: true,
    mine: true,
    floorDelta: "+35.4%",
    highestBid: 0.44,
    bids: [{ id: "bid-178-1", bidder: "0x1163c8A3b4Dd80E8ee066cd5e9F71bd5D3c42Ef0", amount: 0.44, expires: "8h" }],
  },
  {
    tokenId: 188,
    price: 0.64,
    owner: "0x03E62893012B9eC47CC68BB7CFfF64c39Cb00801",
    listed: false,
    vpnAccess: true,
    mine: false,
    floorDelta: "+48.7%",
    highestBid: 0.51,
    bids: [{ id: "bid-188-1", bidder: "0x9Ec6Dfda6989dF29763315644cD8460b2B59C990", amount: 0.51, expires: "5h" }],
  },
];

const dynamicProfiles = [
  { tokenId: 101, ask: 666, bid: 610, rarity: "Genesis", wing: "Neon Cyan", signal: "9.2", orbit: "Lunar Relay", tier: "VPN Prime", state: "Awake" },
  { tokenId: 108, ask: 720, bid: 680, rarity: "Mythic", wing: "Blue Violet", signal: "9.8", orbit: "Deep Space", tier: "AI Plus", state: "Evolving" },
  { tokenId: 117, ask: 780, bid: 700, rarity: "Rare", wing: "Photon Gold", signal: "8.7", orbit: "Mars Arc", tier: "VPN Prime", state: "Awake" },
  { tokenId: 124, ask: 0, bid: 760, rarity: "Legend", wing: "Purple Storm", signal: "9.9", orbit: "Saturn Ring", tier: "AI Prime", state: "Vaulted" },
  { tokenId: 132, ask: 860, bid: 810, rarity: "Mythic", wing: "Aurora Blue", signal: "9.6", orbit: "Nebula Gate", tier: "AI Plus", state: "Evolving" },
  { tokenId: 149, ask: 930, bid: 850, rarity: "Epic", wing: "Plasma Pink", signal: "7.4", orbit: "Comet Line", tier: "Market", state: "Cooling" },
  { tokenId: 156, ask: 1040, bid: 940, rarity: "Rare", wing: "Ion Azure", signal: "8.9", orbit: "Signal Belt", tier: "VPN Prime", state: "Awake" },
  { tokenId: 163, ask: 0, bid: 990, rarity: "Legend", wing: "Solar Violet", signal: "9.7", orbit: "Black Orbit", tier: "AI Prime", state: "Vaulted" },
  { tokenId: 178, ask: 1280, bid: 1160, rarity: "Genesis", wing: "Gold Pulse", signal: "9.4", orbit: "Earth Gate", tier: "AI Plus", state: "Boosted" },
  { tokenId: 188, ask: 1480, bid: 1320, rarity: "Epic", wing: "Cosmic Cyan", signal: "9.1", orbit: "Outer Rim", tier: "VPN Prime", state: "Awake" },
];

export const marketplaceItems = rawMarketplaceItems.map((item) => {
  const profile = dynamicProfiles.find((entry) => entry.tokenId === item.tokenId);
  const ask = profile?.ask || Math.round(item.price * 3600);
  const bestBid = profile?.bid || Math.round((item.highestBid || item.price * 0.82) * 3600);
  return {
    ...item,
    collectionId: "caiwing-nfa",
    collectionName: "财翼 NFA",
    sourcePlatform: "Flap",
    bnbReference: item.price,
    price: null,
    suggestedAsk: ask || bestBid + 160,
    listed: false,
    highestBid: bestBid,
    tokenSymbol: "财翼",
    settlementType: "Token escrow",
    editionSupply: 666,
    dynamicProfile: profile,
    bids: (item.bids || []).map((bid, index) => ({
      ...bid,
      amount: Math.max(bestBid - index * 55, 120),
      tokenSymbol: "财翼",
    })),
  };
});

export const externalFlapMarketplaceItems = [
  {
    tokenId: 12,
    collectionId: "flapixel-vault",
    collectionName: "FLAPixel NFT Vault",
    sourcePlatform: "Flap",
    owner: "0x91fE4D119f9fE100E8fb126A837d85D3FaAd4001",
    listed: false,
    price: null,
    suggestedAsk: 4200,
    highestBid: 3600,
    tokenSymbol: "财翼",
    settlementType: "Cross-Flap token escrow",
    editionSupply: 333,
    vpnAccess: false,
    mine: false,
    dynamicProfile: { rarity: "Vault", wing: "Pixel Gold", signal: "7.6", orbit: "Flap Vault", tier: "Trade", state: "Imported" },
    bids: [{ id: "bid-pixel-12-1", bidder: "0x4A905d5B113C8eE79D777e0Dd9e5099db43B28Ee", amount: 3600, expires: "16h", tokenSymbol: "财翼" }],
  },
  {
    tokenId: 77,
    collectionId: "flapixel-vault",
    collectionName: "FLAPixel NFT Vault",
    sourcePlatform: "Flap",
    owner: "0xB4bY7dEF3a991C0b2F9614A0F0c8c2B8bCC09F12",
    listed: false,
    price: null,
    suggestedAsk: 5100,
    highestBid: 4800,
    tokenSymbol: "财翼",
    settlementType: "Cross-Flap token escrow",
    editionSupply: 333,
    vpnAccess: false,
    mine: true,
    dynamicProfile: { rarity: "Imported", wing: "Pixel Violet", signal: "8.1", orbit: "Flap Vault", tier: "Trade", state: "Owned" },
    bids: [{ id: "bid-pixel-77-1", bidder: "0x725Cda55940F8f13F2090975331EF0176b123C23", amount: 4800, expires: "1d", tokenSymbol: "财翼" }],
  },
  {
    tokenId: 204,
    collectionId: "flap-asteroid",
    collectionName: "Flap Asteroid Pass",
    sourcePlatform: "Flap",
    owner: "0x2B9E1687b6dB28905988501A108D6C2C322FdB33",
    listed: false,
    price: null,
    suggestedAsk: 2800,
    highestBid: 2300,
    tokenSymbol: "财翼",
    settlementType: "Cross-Flap token escrow",
    editionSupply: 512,
    vpnAccess: false,
    mine: false,
    dynamicProfile: { rarity: "Asteroid", wing: "Orbit Silver", signal: "6.9", orbit: "Asteroid Belt", tier: "Trade", state: "Imported" },
    bids: [{ id: "bid-asteroid-204-1", bidder: "0xc4EC6B4E634b352F64Fc34d9B738B2A356F6e280", amount: 2300, expires: "20h", tokenSymbol: "财翼" }],
  },
];

export const myNfas = marketplaceItems.filter((item) => item.mine);

export const vpnMockStatus = {
  connected: true,
  isHolder: true,
  vpnActive: true,
  holderTokenIds: walletMock.verifiedNfas,
  subscriptionUrl: "https://api.财翼.example/vpn/clash/bx_[masked-token]",
  expiresIn: "30 days",
  bandwidthUsed: "18.4 GB",
  deviceLimit: 5,
  activeDevices: 2,
  lastRefresh: "2026-05-06 00:18",
  policy: "Holder subscription token is issued by backend only. No real VPN node config is stored in frontend.",
};

export const vpnDevices = [
  { id: "mac", name: "MacBook Pro", client: "Clash Verge", status: "Active", region: "Auto" },
  { id: "phone", name: "iPhone", client: "Stash", status: "Active", region: "HK Relay" },
  { id: "spare", name: "Windows Laptop", client: "Clash Meta", status: "Idle", region: "Auto" },
];

export const agentVaultMock = {
  wallet: walletMock.address,
  isHolder: true,
  balance: 2.5,
  available: 1.1,
  allocated: 1.4,
  simulatedPnl: 0.186,
  pnlPercent: 7.44,
  riskMode: "Balanced",
  maxDailyLoss: "3.0%",
  status: "Simulation Active",
  disclaimer:
    "AI Agent strategies are simulated in this frontend. Real quant or on-chain execution requires backend risk controls and can lose funds. Profit is not guaranteed.",
};

export const agentStrategies = [
  {
    id: "market-neutral",
    name: "Market Neutral Grid",
    type: "Quant",
    target: "Stable range trading",
    risk: "Medium",
    allocation: 0.6,
    pnl: "+4.8%",
    status: "Running",
  },
  {
    id: "onchain-arb",
    name: "On-chain Arbitrage Watcher",
    type: "On-chain",
    target: "DEX spread alerts and execution queue",
    risk: "High",
    allocation: 0.5,
    pnl: "+9.2%",
    status: "Queued",
  },
  {
    id: "nft-liquidity",
    name: "NFT Liquidity Manager",
    type: "Marketplace",
    target: "Bid, list, and rebalance 财翼 NFA inventory",
    risk: "Medium",
    allocation: 0.3,
    pnl: "+2.1%",
    status: "Monitoring",
  },
];

export const agentActivity = [
  { time: "00:12", action: "Scanned 财翼 NFA floor depth", result: "No execution" },
  { time: "00:08", action: "Prepared bid ladder for token #132", result: "Waiting for user approval" },
  { time: "00:03", action: "Rebalanced mock vault allocation", result: "+0.018 BNB simulated" },
];
