import { BABYX_ASSETS } from "../data/mock.js";

export default function DynamicNFAArt({ item, large = false }) {
  const profile = item?.dynamicProfile || {};
  const hue = ((item?.tokenId || 1) * 37) % 360;
  const variant = (item?.tokenId || 0) % 6;

  return (
    <figure
      className={`dynamic-nfa-art variant-${variant} ${large ? "large" : ""}`}
      style={{ "--nfa-hue": `${hue}deg` }}
    >
      <object className="animated-art" data={BABYX_ASSETS.animated} type="image/svg+xml" aria-label={`BabyX NFA #${item?.tokenId || ""}`}>
        <img src={BABYX_ASSETS.poster} alt={`BabyX NFA #${item?.tokenId || ""}`} />
      </object>
      <span className="art-token">#{item?.tokenId}</span>
      <span className="art-rarity">{profile.rarity || "Dynamic"}</span>
      <span className="art-signal">SIG {profile.signal || "--"}</span>
      <i className="art-pulse" />
    </figure>
  );
}
