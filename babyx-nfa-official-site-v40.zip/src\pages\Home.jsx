import HeroBabyX from "../components/HeroBabyX.jsx";
import SectionTitle from "../components/SectionTitle.jsx";
import StatCard from "../components/StatCard.jsx";

export default function Home({ onNavigate, t }) {
  return (
    <>
      <section className="hero shell page-grid two-col">
        <div className="hero-copy">
          <span className="eyebrow">{t.home.eyebrow}</span>
          <h1>{t.home.title}</h1>
          <p className="hero-subtitle">
            {t.home.subtitle.map((line) => (
              <span key={line}>{line}</span>
            ))}
          </p>
          <p className="hero-text">
            {t.home.text.map((line) => (
              <span key={line}>{line}</span>
            ))}
          </p>
          <div className="hero-proof-row">
            {t.home.proof.map((item) => (
              <span key={item}>{item}</span>
            ))}
          </div>
          <div className="hero-actions">
            <button className="primary-button" type="button" onClick={() => onNavigate("mint")}>
              {t.home.mint}
            </button>
            <button className="secondary-button" type="button" onClick={() => onNavigate("marketplace")}>
              {t.home.explore}
            </button>
            <button className="secondary-button blue" type="button" onClick={() => onNavigate("vpn")}>
              {t.home.vpn}
            </button>
          </div>
        </div>
        <HeroBabyX />
      </section>

      <section className="shell stats-grid">
        {t.home.stats.map((stat) => (
          <StatCard key={stat.label} {...stat} />
        ))}
      </section>

      <section className="shell section-block product-system">
        <SectionTitle
          eyebrow={t.home.systemEyebrow}
          title={t.home.systemTitle}
          copy={t.home.systemCopy}
        />
        <div className="system-grid">
          {t.home.mechanics.map(([tag, title, description]) => (
            <article className="system-card" key={title}>
              <span>{tag}</span>
              <h3>{title}</h3>
              <p>{description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="shell section-block">
        <SectionTitle
          eyebrow={t.home.utilitiesEyebrow}
          title={t.home.utilitiesTitle}
          copy={t.home.utilitiesCopy}
        />
        <div className="utility-grid">
          {t.home.utilities.map(([tag, title, description]) => (
            <article className="utility-card" key={title}>
              <span>{tag}</span>
              <h3>{title}</h3>
              <p>{description}</p>
            </article>
          ))}
        </div>
      </section>
    </>
  );
}
