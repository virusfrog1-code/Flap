import { BABYX_ASSETS } from "../data/mock.js";

export default function HeroBabyX({ compact = false }) {
  return (
    <div className={`babyx-visual ${compact ? "compact" : ""}`}>
      <div className="visual-glow" />
      <div className="nft-frame">
        <object className="animated-art" data={BABYX_ASSETS.animated} type="image/svg+xml" aria-label="BabyX NFA space butterfly animated NFT">
          <img src={BABYX_ASSETS.poster} alt="BabyX NFA space butterfly NFT" />
        </object>
      </div>
      <div className="orbit-chip top">Dynamic SVG</div>
      <div className="orbit-chip bottom">Holder Utility</div>
    </div>
  );
}
