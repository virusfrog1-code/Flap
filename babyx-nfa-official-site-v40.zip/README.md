# BabyX NFA Platform

BabyX NFA is a Vite + React Web3 frontend for a dynamic NFT access platform.

## Product Surface

- Dynamic NFT identity with Flap official mint entry
- NFT marketplace mock experience
- Holder dashboard for BabyX NFA utilities
- Holder-gated VPN panel with masked Clash subscription flow
- AI Agent console with mocked holder access
- Static image schema deploy entry at `/deploy-image-schema.html?exact=v12`

## Static Assets

Required public assets are served from:

- `/assets/babyx-nfa-butterfly-space-animated.svg`
- `/assets/babyx-nfa-butterfly-space-960.jpg`
- `/artifacts/BabyXNFAImageSchema.json`
- `/deploy-image-schema.html?exact=v12`

## Development

```bash
npm install
npm run dev
npm run build
```

The current frontend uses mock data and reserved service methods in `src/services/api.js`. Real wallet, marketplace,
VPN, Clash, and AI Agent integrations should be connected through backend APIs. Do not place secrets, real VPN nodes, or
private credentials in the frontend.
