export default function AccessGate({ title, checks, locked = false, children, eyebrow = "Holder Gate", lockedCopy }) {
  if (locked) {
    return (
      <section className="access-gate locked">
        <span className="lock-icon">LOCK</span>
        <h2>{title}</h2>
        <p>{lockedCopy || "BabyX NFA required to unlock AI Agent"}</p>
      </section>
    );
  }

  return (
    <section className="access-gate">
      <div>
        <span className="eyebrow">{eyebrow}</span>
        <h2>{title}</h2>
      </div>
      <div className="gate-checks">
        {checks.map((check) => (
          <span key={check}>{check}</span>
        ))}
      </div>
      {children}
    </section>
  );
}
