import { walletMock } from "../data/mock.js";

export default function WalletButton({ label = "Connect Wallet" }) {
  return (
    <button className="wallet-button" type="button">
      <span className="status-dot" />
      {label}
      <small>{walletMock.address}</small>
    </button>
  );
}
