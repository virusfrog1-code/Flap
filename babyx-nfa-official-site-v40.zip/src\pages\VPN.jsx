import { useEffect, useState } from "react";
import AccessGate from "../components/AccessGate.jsx";
import SectionTitle from "../components/SectionTitle.jsx";
import { walletMock } from "../data/mock.js";
import { getVpnStatus, issueVpnSubscription, revokeVpnDevice, verifyVpnHolder } from "../services/api.js";

export default function VPN({ t }) {
  const [status, setStatus] = useState(null);
  const [copied, setCopied] = useState(false);
  const [actionLog, setActionLog] = useState(t.vpn.ready);

  useEffect(() => {
    getVpnStatus(walletMock.address).then(setStatus);
  }, []);

  useEffect(() => {
    setActionLog(t.vpn.ready);
  }, [t]);

  const verify = async () => {
    const result = await verifyVpnHolder(walletMock.address);
    setStatus((current) => ({ ...current, isHolder: result.isHolder, holderTokenIds: result.tokenIds }));
    setActionLog(`${t.vpn.verifiedLog} #${result.tokenIds.join(", #")}.`);
  };

  const refresh = async () => {
    const next = await issueVpnSubscription(walletMock.address);
    setStatus((current) => ({ ...current, ...next, vpnActive: true }));
    setActionLog(t.vpn.refreshedLog);
  };

  const copy = async () => {
    if (!status?.subscriptionUrl) return;
    await navigator.clipboard?.writeText(status.subscriptionUrl);
    setCopied(true);
    setActionLog(t.vpn.copiedLog);
    window.setTimeout(() => setCopied(false), 1600);
  };

  const revoke = async (deviceId) => {
    const result = await revokeVpnDevice(deviceId);
    setStatus((current) => ({
      ...current,
      devices: current.devices.map((device) => (device.id === deviceId ? { ...device, status: "Revoked" } : device)),
    }));
    setActionLog(`${result.deviceId}: ${t.vpn.revokedLog}`);
  };

  const gateChecks = [
    status?.connected ? t.vpn.checks[0] : t.vpn.walletRequired,
    status?.isHolder ? t.vpn.checks[1] : t.vpn.holderRequired,
    status?.vpnActive ? t.vpn.checks[2] : t.vpn.vpnInactive,
  ];

  return (
    <section className="shell section-block">
      <SectionTitle
        eyebrow={t.vpn.eyebrow}
        title={t.vpn.title}
        copy={t.vpn.copy}
      />

      <div className="core-dashboard">
        <AccessGate title={t.vpn.gateTitle} checks={gateChecks} eyebrow={t.vpn.accessGate}>
          <div className="holder-proof">
            <span>{t.vpn.verifiedNfts}</span>
            <strong>{status?.holderTokenIds?.map((id) => `#${id}`).join("  ") || t.vpn.checking}</strong>
            <button className="primary-button" type="button" onClick={verify}>
              {t.vpn.verify}
            </button>
          </div>
        </AccessGate>

        <article className="glass-panel subscription-card pro-card">
          <div className="panel-split-head">
            <div>
              <span className="eyebrow">{t.vpn.subscription}</span>
              <h3>{t.vpn.vault}</h3>
            </div>
            <strong className="live-pill">{status?.vpnActive ? t.vpn.active : t.vpn.locked}</strong>
          </div>

          <div className="masked-url">{status?.subscriptionUrl || t.vpn.loading}</div>

          <div className="vpn-metrics">
            <span>
              {t.vpn.expires} <strong>{status?.expiresIn || "--"}</strong>
            </span>
            <span>
              {t.vpn.usage} <strong>{status?.bandwidthUsed || "--"}</strong>
            </span>
            <span>
              {t.vpn.devices} <strong>{status ? `${status.activeDevices}/${status.deviceLimit}` : "--"}</strong>
            </span>
          </div>

          <div className="button-row">
            <button className="primary-button" type="button" onClick={copy}>
              {copied ? t.common.copied : t.vpn.copyButton}
            </button>
            <button className="secondary-button" type="button">
              {t.vpn.import}
            </button>
            <button className="secondary-button blue" type="button">
              {t.vpn.download}
            </button>
            <button className="secondary-button" type="button" onClick={refresh}>
              {t.vpn.refresh}
            </button>
          </div>
        </article>
      </div>

      <div className="vpn-ops-grid">
        <article className="glass-panel">
          <h3>{t.vpn.deviceSessions}</h3>
          <div className="device-table">
            {(status?.devices || []).map((device) => (
              <div className="device-row" key={device.id}>
                <div>
                  <strong>{device.name}</strong>
                  <span>{device.client} / {device.region}</span>
                </div>
                <small className={device.status.toLowerCase()}>{device.status}</small>
                <button className="mini-button" type="button" onClick={() => revoke(device.id)} disabled={device.status === "Revoked"}>
                  {t.vpn.revoke}
                </button>
              </div>
            ))}
          </div>
        </article>

        <article className="glass-panel">
          <h3>{t.vpn.setupFlow}</h3>
          <div className="tutorial-grid compact">
            {t.vpn.steps.map((step, index) => (
              <article className="step-card" key={step}>
                <span>{index + 1}</span>
                <strong>{step}</strong>
              </article>
            ))}
          </div>
        </article>
      </div>

      <article className="risk-note">
        <strong>{actionLog}</strong>
        <p>{status?.policy || t.vpn.risk}</p>
      </article>
    </section>
  );
}
