﻿import { useEffect, useMemo, useState } from "react";
import DynamicNFAArt from "../components/DynamicNFAArt.jsx";
import NFTCard from "../components/NFTCard.jsx";
import SectionTitle from "../components/SectionTitle.jsx";
import { walletMock } from "../data/mock.js";
import {
  acceptMarketplaceBid,
  buyMarketplaceItem,
  cancelMarketplaceListing,
  createMarketplaceListing,
  getFlapCollections,
  getFlapTaxInfo,
  getMarketplaceListings,
  placeMarketplaceBid,
  syncFlapCollection,
} from "../services/api.js";

const shortAddress = (address) => `${address.slice(0, 6)}...${address.slice(-4)}`;
const formatToken = (amount, symbol = "财翼") => `${Number(amount || 0).toLocaleString("en-US")} ${symbol}`;

export default function Marketplace({ t }) {
  const [items, setItems] = useState([]);
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState("low");
  const [filter, setFilter] = useState("all");
  const [selected, setSelected] = useState(null);
  const [taxInfo, setTaxInfo] = useState(null);
  const [collections, setCollections] = useState([]);
  const [activeCollection, setActiveCollection] = useState("all");
  const [syncStatus, setSyncStatus] = useState("");
  const [listPrice, setListPrice] = useState("720");
  const [bidAmount, setBidAmount] = useState("680");
  const [orderStatus, setOrderStatus] = useState(t.marketplace.ready);

  useEffect(() => {
    Promise.all([getMarketplaceListings(), getFlapTaxInfo(), getFlapCollections()]).then(([listings, tax, flap]) => {
      setItems(listings);
      setTaxInfo(tax);
      setCollections(flap.collections);
    });
  }, []);

  const marketStats = useMemo(() => {
    const listed = items.filter((item) => item.listed);
    const activeAsks = listed.map((item) => item.price).filter(Boolean);
    const bestBid = items.length ? Math.max(...items.map((item) => item.highestBid || 0)) : 0;
    const askBand = activeAsks.length
      ? `${Math.min(...activeAsks).toLocaleString()}-${Math.max(...activeAsks).toLocaleString()}`
      : t.marketplace.noAsks;
    return [
      { label: t.marketplace.listedCount, value: listed.length, note: t.marketplace.listedNote },
      { label: t.marketplace.askBand, value: askBand, note: t.marketplace.askNote },
      { label: t.marketplace.bestOffer, value: formatToken(bestBid), note: t.marketplace.offerNote },
      { label: t.marketplace.flapCollections || "Flap Collections", value: collections.length, note: t.marketplace.crossCollectionNote || "cross-market adapters" },
    ];
  }, [collections.length, items, t]);

  const visibleItems = useMemo(() => {
    return items
      .filter((item) => {
        const searchText = `${item.collectionName || "财翼 NFA"} #${item.tokenId}`.toLowerCase();
        const matchesSearch = searchText.includes(query.toLowerCase());
        const matchesCollection = activeCollection === "all" || item.collectionId === activeCollection;
        const matchesFilter =
          filter === "all" ||
          (filter === "listed" && item.listed) ||
          (filter === "mine" && item.mine) ||
          (filter === "vpn" && item.vpnAccess);
        return matchesSearch && matchesCollection && matchesFilter;
      })
      .sort((a, b) => {
        const aValue = a.listed ? a.price : a.highestBid || a.suggestedAsk || 0;
        const bValue = b.listed ? b.price : b.highestBid || b.suggestedAsk || 0;
        if (sort === "high") return bValue - aValue;
        if (sort === "token") return a.tokenId - b.tokenId;
        return aValue - bValue;
      });
  }, [activeCollection, filter, items, query, sort]);

  const updateItem = (tokenId, updater) => {
    setItems((current) => current.map((item) => (item.tokenId === tokenId ? updater(item) : item)));
    setSelected((current) => (current?.tokenId === tokenId ? updater(current) : current));
  };

  const listSelected = async () => {
    if (!selected) return;
    const price = Number(listPrice);
    if (!Number.isFinite(price) || price <= 0) {
      setOrderStatus(t.marketplace.invalidAsk);
      return;
    }
    const result = await createMarketplaceListing({ tokenId: selected.tokenId, price });
    updateItem(selected.tokenId, (item) => ({ ...item, listed: true, price }));
    setOrderStatus(`${t.marketplace.listedStatus}: #${result.tokenId} / ${formatToken(price, selected.tokenSymbol)}.`);
  };

  const cancelSelected = async () => {
    if (!selected) return;
    const result = await cancelMarketplaceListing({ tokenId: selected.tokenId });
    updateItem(selected.tokenId, (item) => ({ ...item, listed: false, price: null }));
    setOrderStatus(`${t.marketplace.cancelledStatus}: #${result.tokenId}.`);
  };

  const buySelected = async () => {
    if (!selected) return;
    const result = await buyMarketplaceItem({ tokenId: selected.tokenId, price: selected.price });
    updateItem(selected.tokenId, (item) => ({
      ...item,
      mine: true,
      owner: "0xB4bY7dEF3a991C0b2F9614A0F0c8c2B8bCC09F12",
      listed: false,
    }));
    setOrderStatus(`${t.marketplace.purchaseStatus}: #${result.tokenId}.`);
  };

  const bidSelected = async () => {
    if (!selected) return;
    const amount = Number(bidAmount);
    if (!Number.isFinite(amount) || amount <= 0) {
      setOrderStatus(t.marketplace.invalidOffer);
      return;
    }
    const result = await placeMarketplaceBid({ tokenId: selected.tokenId, amount });
    const bid = { id: result.bidId, bidder: walletMock.address, amount, expires: "24h", tokenSymbol: selected.tokenSymbol };
    updateItem(selected.tokenId, (item) => ({
      ...item,
      highestBid: Math.max(item.highestBid || 0, amount),
      bids: [bid, ...(item.bids || [])],
    }));
    setOrderStatus(`${t.marketplace.offerStatus}: #${result.tokenId} / ${formatToken(amount, selected.tokenSymbol)}.`);
  };

  const acceptBid = async (bid) => {
    if (!selected) return;
    const result = await acceptMarketplaceBid({ tokenId: selected.tokenId, bidId: bid.id });
    updateItem(selected.tokenId, (item) => ({
      ...item,
      listed: false,
      mine: false,
      owner: bid.bidder,
      price: null,
      highestBid: 0,
      bids: [],
    }));
    setOrderStatus(`${t.marketplace.acceptedStatus}: ${result.bidId} / #${result.tokenId}.`);
  };

  const syncCollection = async (collectionId) => {
    const result = await syncFlapCollection(collectionId);
    const collection = collections.find((item) => item.id === collectionId);
    setSyncStatus(`${collection?.name || collectionId}: ${result.status}`);
  };

  return (
    <section className="shell section-block">
      <SectionTitle
        eyebrow={t.marketplace.eyebrow}
        title={t.marketplace.title}
        copy={t.marketplace.copy}
      />

      <div className="tax-vault-grid">
        <article className="glass-panel tax-vault-card">
          <div className="panel-split-head">
            <div>
              <span className="eyebrow">{t.marketplace.taxVault || "Flap Tax Vault"}</span>
              <h3>{taxInfo?.title || t.common.loading}</h3>
            </div>
            <a className="mini-button" href={taxInfo?.source} target="_blank" rel="noreferrer">
              {t.marketplace.openTaxInfo || "Open Taxinfo"}
            </a>
          </div>
          <div className="tax-metrics">
            <span>
              {t.marketplace.minted || "Minted"} <strong>{taxInfo ? `${taxInfo.minted}/${taxInfo.totalSupply}` : "--"}</strong>
            </span>
            <span>
              {t.marketplace.redeemCost || "Redeem Cost"} <strong>{taxInfo?.redeemCostLabel || "--"}</strong>
            </span>
            <span>
              {t.marketplace.dividend || "Dividend"} <strong>{taxInfo?.dividendRatio || "--"}</strong>
            </span>
            <span>
              {t.marketplace.dividendTax || "Dividend Tax"} <strong>{taxInfo?.dividendTax || "--"}</strong>
            </span>
            <span>
              {t.marketplace.floorTax || "Floor Tax"} <strong>{taxInfo?.floorTax || "--"}</strong>
            </span>
            <span>
              {t.marketplace.receivedToken || "Received Token"} <strong>{taxInfo?.totalReceivedToken || "--"}</strong>
            </span>
          </div>
        </article>

        <article className="glass-panel flap-adapter-card">
          <div className="panel-split-head">
            <div>
              <span className="eyebrow">{t.marketplace.flapAdapter || "Flap NFT Adapter"}</span>
              <h3>{t.marketplace.crossCollectionTitle || "Cross-collection trading"}</h3>
            </div>
            <span>{syncStatus || t.marketplace.syncReady || "Mock API ready"}</span>
          </div>
          <div className="collection-sync-list">
            {collections.map((collection) => (
              <button
                className={activeCollection === collection.id ? "active" : ""}
                type="button"
                key={collection.id}
                onClick={() => {
                  setActiveCollection(collection.id);
                  syncCollection(collection.id);
                }}
              >
                <strong>{collection.name}</strong>
                <small>{collection.minted}/{collection.supply} · {collection.settlement}</small>
              </button>
            ))}
          </div>
        </article>
      </div>

      <div className="market-command">
        {marketStats.map((stat) => (
          <article className="command-stat" key={stat.label}>
            <span>{stat.label}</span>
            <strong>{stat.value}</strong>
            <small>{stat.note}</small>
          </article>
        ))}
      </div>

      <div className="market-toolbar pro">
        <input
          type="search"
          placeholder={t.marketplace.search}
          value={query}
          onChange={(event) => setQuery(event.target.value)}
        />
        <select value={sort} onChange={(event) => setSort(event.target.value)}>
          <option value="low">{t.marketplace.sortLow}</option>
          <option value="high">{t.marketplace.sortHigh}</option>
          <option value="token">{t.marketplace.sortToken}</option>
        </select>
        <select value={activeCollection} onChange={(event) => setActiveCollection(event.target.value)}>
          <option value="all">{t.marketplace.allCollections || "All Flap collections"}</option>
          {collections.map((collection) => (
            <option value={collection.id} key={collection.id}>
              {collection.name}
            </option>
          ))}
        </select>
        <div className="segmented">
          <button className={filter === "listed" ? "active" : ""} type="button" onClick={() => setFilter("listed")}>
            {t.marketplace.listedOnly}
          </button>
          <button className={filter === "mine" ? "active" : ""} type="button" onClick={() => setFilter("mine")}>
            {t.marketplace.myNfts}
          </button>
          <button className={filter === "vpn" ? "active" : ""} type="button" onClick={() => setFilter("vpn")}>
            {t.marketplace.hasVpn}
          </button>
          <button className={filter === "all" ? "active" : ""} type="button" onClick={() => setFilter("all")}>
            {t.marketplace.all}
          </button>
        </div>
      </div>

      <div className="nft-grid market-grid">
        {visibleItems.map((item) => (
          <NFTCard
            key={item.tokenId}
            item={item}
            onSelect={(next) => {
              setSelected(next);
              setListPrice(String(next.price || next.suggestedAsk || 666));
              setBidAmount(String(Math.max(next.highestBid || 120, 120)));
              setOrderStatus(t.marketplace.ready);
            }}
            labels={{
              listed: t.common.listed,
              vault: t.common.vault,
              vpnAccess: t.marketplace.vpnAccess,
              vpnPending: t.marketplace.vpnPending,
              buy: t.common.buy,
              view: t.common.view,
              makeOffer: t.marketplace.placeOffer,
              suggestedAsk: t.marketplace.suggestedAsk,
            }}
          />
        ))}
        {!visibleItems.length ? <article className="empty-market glass-panel">{t.marketplace.empty}</article> : null}
      </div>

      {selected ? (
        <div className="modal-backdrop" role="presentation" onClick={() => setSelected(null)}>
          <section className="nft-modal order-modal" role="dialog" aria-modal="true" onClick={(event) => event.stopPropagation()}>
            <button className="modal-close" type="button" onClick={() => setSelected(null)} aria-label={t.marketplace.close}>
              x
            </button>

            <div className="order-preview">
              <DynamicNFAArt item={selected} large />
              <div className="badge-row">
                <span>{selected.vpnAccess ? t.marketplace.vpnActive : t.marketplace.vpnPending}</span>
                <span>{selected.listed ? t.common.listed : t.common.vault}</span>
                <span>{t.marketplace.bestOffer} {formatToken(selected.highestBid, selected.tokenSymbol)}</span>
              </div>
            </div>

            <div className="order-console">
              <span className="eyebrow">{t.marketplace.detail}</span>
              <h2>{selected.collectionName || "财翼 NFA"} #{selected.tokenId}</h2>
              <div className="dynamic-trait-panel">
                <span>{selected.dynamicProfile?.rarity}</span>
                <span>{selected.dynamicProfile?.wing}</span>
                <span>{selected.dynamicProfile?.orbit}</span>
                <span>{t.marketplace.signal} {selected.dynamicProfile?.signal}</span>
                <span>{selected.dynamicProfile?.tier}</span>
                <span>{selected.dynamicProfile?.state}</span>
              </div>
              <dl className="detail-list">
                <div>
                  <dt>{t.marketplace.collection || "Collection"}</dt>
                  <dd>{selected.collectionName}</dd>
                </div>
                <div>
                  <dt>{t.marketplace.owner}</dt>
                  <dd>{shortAddress(selected.owner)}</dd>
                </div>
                <div>
                  <dt>{t.marketplace.askOrder}</dt>
                  <dd>{selected.listed ? formatToken(selected.price, selected.tokenSymbol) : t.common.notListed}</dd>
                </div>
                <div>
                  <dt>{t.marketplace.highestOffer}</dt>
                  <dd>{formatToken(selected.highestBid, selected.tokenSymbol)}</dd>
                </div>
                <div>
                  <dt>{t.marketplace.settlement}</dt>
                  <dd>{selected.settlementType}</dd>
                </div>
              </dl>

              <div className="order-forms">
                <article>
                  <h3>{t.marketplace.sellerOrder}</h3>
                  <label>
                    {t.marketplace.askInput} ({selected.tokenSymbol})
                    <input value={listPrice} onChange={(event) => setListPrice(event.target.value)} inputMode="decimal" />
                  </label>
                  <div className="button-row">
                    <button className="primary-button" type="button" onClick={listSelected} disabled={!selected.mine}>
                      {t.marketplace.listAsk}
                    </button>
                    <button className="secondary-button" type="button" onClick={cancelSelected} disabled={!selected.mine || !selected.listed}>
                      {t.marketplace.cancel}
                    </button>
                  </div>
                </article>

                <article>
                  <h3>{t.marketplace.buyerOffer}</h3>
                  <label>
                    {t.marketplace.offerInput} ({selected.tokenSymbol})
                    <input value={bidAmount} onChange={(event) => setBidAmount(event.target.value)} inputMode="decimal" />
                  </label>
                  <div className="button-row">
                    <button className="secondary-button blue" type="button" onClick={bidSelected}>
                      {t.marketplace.placeOffer}
                    </button>
                    <button className="primary-button" type="button" onClick={buySelected} disabled={!selected.listed || selected.mine}>
                      {t.marketplace.executeAsk}
                    </button>
                  </div>
                </article>
              </div>

              <article className="order-book">
                <div className="order-book-head">
                  <h3>{t.marketplace.offerBook}</h3>
                  <span>{orderStatus}</span>
                </div>
                {(selected.bids || []).length ? (
                  selected.bids.map((bid) => (
                    <div className="bid-row" key={bid.id}>
                      <span>{shortAddress(bid.bidder)}</span>
                      <strong>{formatToken(bid.amount, bid.tokenSymbol || selected.tokenSymbol)}</strong>
                      <small>{bid.expires}</small>
                      <button className="mini-button primary" type="button" onClick={() => acceptBid(bid)} disabled={!selected.mine}>
                        {t.marketplace.accept}
                      </button>
                    </div>
                  ))
                ) : (
                  <p>{t.marketplace.noOffers}</p>
                )}
              </article>
            </div>
          </section>
        </div>
      ) : null}
    </section>
  );
}
