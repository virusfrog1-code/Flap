import { useEffect, useMemo, useState } from "react";
import AccessGate from "../components/AccessGate.jsx";
import SectionTitle from "../components/SectionTitle.jsx";
import { walletMock } from "../data/mock.js";
import {
  depositAgentFunds,
  getAgentAccess,
  getAgentVault,
  sendAgentMessage,
  startAgentStrategy,
  withdrawAgentFunds,
} from "../services/api.js";

const formatBnb = (value = 0) => `${Number(value).toFixed(3)} BNB`;

export default function AIAgent({ t }) {
  const [activeAgent, setActiveAgent] = useState(t.agent.agents[0]);
  const [messages, setMessages] = useState([{ role: "ai", text: t.agent.hello }]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [access, setAccess] = useState(true);
  const [vault, setVault] = useState(null);
  const [depositAmount, setDepositAmount] = useState("0.50");
  const [withdrawAmount, setWithdrawAmount] = useState("0.20");
  const [allocationAmount, setAllocationAmount] = useState("0.30");
  const [selectedStrategy, setSelectedStrategy] = useState("market-neutral");
  const [actionStatus, setActionStatus] = useState(t.agent.consoleReady);

  useEffect(() => {
    Promise.all([getAgentAccess(walletMock.address), getAgentVault(walletMock.address)]).then(([accessResult, vaultResult]) => {
      setAccess(accessResult.access);
      setVault(vaultResult);
      setSelectedStrategy(vaultResult.strategies[0]?.id || "market-neutral");
    });
  }, []);

  useEffect(() => {
    setActiveAgent(t.agent.agents[0]);
    setMessages([{ role: "ai", text: t.agent.hello }]);
    setActionStatus(t.agent.consoleReady);
  }, [t]);

  const selectedStrategyName = useMemo(() => {
    return vault?.strategies.find((strategy) => strategy.id === selectedStrategy)?.name || "Agent Strategy";
  }, [selectedStrategy, vault]);

  const pushActivity = (action, result) => {
    setVault((current) => {
      if (!current) return current;
      const time = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
      return {
        ...current,
        activity: [{ time, action, result }, ...(current.activity || [])].slice(0, 6),
      };
    });
  };

  const runDeposit = async () => {
    const amount = Number(depositAmount);
    if (!vault) {
      setActionStatus(t.agent.vaultLoading);
      return;
    }
    if (!Number.isFinite(amount) || amount <= 0) {
      setActionStatus(t.agent.invalidDeposit);
      return;
    }

    setActionStatus(t.agent.preparingDeposit);
    const result = await depositAgentFunds({ amount, strategy: selectedStrategy });
    setVault((current) => ({
      ...current,
      balance: Number((current.balance + result.amount).toFixed(3)),
      available: Number((current.available + result.amount).toFixed(3)),
    }));
    pushActivity(`Deposited ${formatBnb(result.amount)} into ${selectedStrategyName}`, t.agent.mockBalanceUpdated);
    setActionStatus(`Mock deposit complete: ${formatBnb(result.amount)} reserved for ${selectedStrategyName}.`);
  };

  const runWithdraw = async () => {
    const amount = Number(withdrawAmount);
    if (!vault || !Number.isFinite(amount) || amount <= 0) {
      setActionStatus(t.agent.invalidWithdraw);
      return;
    }
    if (amount > vault.available) {
      setActionStatus(t.agent.withdrawalTooHigh);
      return;
    }

    setActionStatus(t.agent.submittingWithdraw);
    const result = await withdrawAgentFunds({ amount });
    setVault((current) => ({
      ...current,
      balance: Number((current.balance - result.amount).toFixed(3)),
      available: Number((current.available - result.amount).toFixed(3)),
    }));
    pushActivity(`Requested withdrawal ${formatBnb(result.amount)}`, t.agent.pendingSettlement);
    setActionStatus(`Mock withdrawal requested: ${formatBnb(result.amount)}.`);
  };

  const launchStrategy = async (strategyId) => {
    const allocation = Number(allocationAmount);
    if (!vault || !Number.isFinite(allocation) || allocation <= 0) {
      setActionStatus(t.agent.invalidAllocation);
      return;
    }
    if (allocation > vault.available) {
      setActionStatus(t.agent.allocationTooHigh);
      return;
    }

    const strategy = vault.strategies.find((item) => item.id === strategyId);
    setActionStatus(`${t.agent.preparingStrategy} ${strategy?.name || ""}`.trim());
    const result = await startAgentStrategy({ strategyId, allocation });
    setVault((current) => ({
      ...current,
      available: Number((current.available - result.allocation).toFixed(3)),
      allocated: Number((current.allocated + result.allocation).toFixed(3)),
      strategies: current.strategies.map((item) =>
        item.id === strategyId
          ? {
              ...item,
              status: "Running",
              allocation: Number((item.allocation + result.allocation).toFixed(3)),
            }
          : item,
      ),
    }));
    pushActivity(`Started ${strategy?.name || strategyId} with ${formatBnb(result.allocation)}`, t.agent.mockQueued);
    setActionStatus(`${strategy?.name || "Strategy"} queued through mock API. ${t.agent.realApprovalRequired}`);
  };

  const send = async () => {
    const text = input.trim();
    if (!text) return;
    setMessages((current) => [...current, { role: "user", text }]);
    setInput("");
    setLoading(true);
    const result = await sendAgentMessage(text, walletMock.address);
    setMessages((current) => [...current, { role: "ai", text: result.reply }]);
    setLoading(false);
  };

  if (!access) {
    return (
      <section className="shell section-block">
        <AccessGate title={t.agent.lockedTitle} locked checks={[]} lockedCopy={t.common.lockedAgent} />
      </section>
    );
  }

  const gateChecks = [
    walletMock.connected ? t.agent.walletConnected : t.agent.walletRequired,
    walletMock.isHolder ? t.agent.nfaVerified : t.agent.nfaRequired,
    vault?.status || t.agent.loadingVault,
  ];

  return (
    <section className="shell section-block">
      <SectionTitle
        eyebrow={t.agent.eyebrow}
        title={t.agent.title}
        copy={t.agent.copy}
      />

      <div className="agent-access-strip">
        <AccessGate title={t.agent.gateTitle} checks={gateChecks} eyebrow={t.agent.accessGate}>
          <p>{t.agent.gateCopy}</p>
        </AccessGate>
      </div>

      <div className="agent-command-center">
        <aside className="agent-rail glass-panel">
          <div>
            <span className="eyebrow">{t.agent.active}</span>
            <h3>{t.agent.modules}</h3>
          </div>
          {t.agent.agents.map((agent) => (
            <button
              className={agent === activeAgent ? "active" : ""}
              type="button"
              key={agent}
              onClick={() => setActiveAgent(agent)}
            >
              {agent}
            </button>
          ))}
          <div className="agent-capability-stack">
            {t.agent.capabilityList.map((capability) => (
              <span key={capability}>{capability}</span>
            ))}
            <span>{t.agent.quantAllocation}</span>
            <span>{t.agent.executionQueue}</span>
          </div>
        </aside>

        <main className="agent-workbench">
          <section className="vault-panel glass-panel">
            <div className="panel-split-head">
              <div>
                <span className="eyebrow">{t.agent.capitalVault}</span>
                <h2>{vault?.status || t.common.loading}</h2>
              </div>
              <strong className="live-pill">{vault?.riskMode || t.agent.riskMode}</strong>
            </div>

            <div className="vault-metrics">
              <article>
                <span>{t.agent.totalBalance}</span>
                <strong>{formatBnb(vault?.balance)}</strong>
              </article>
              <article>
                <span>{t.agent.available}</span>
                <strong>{formatBnb(vault?.available)}</strong>
              </article>
              <article>
                <span>{t.agent.allocated}</span>
                <strong>{formatBnb(vault?.allocated)}</strong>
              </article>
              <article>
                <span>{t.agent.simulatedPnl}</span>
                <strong className="pnl-positive">
                  +{formatBnb(vault?.simulatedPnl)} / +{vault?.pnlPercent || "0.00"}%
                </strong>
              </article>
            </div>

            <div className="funding-grid">
              <article className="funding-form">
                <h3>{t.agent.depositTitle}</h3>
                <label>
                  {t.agent.amount}
                  <input value={depositAmount} onChange={(event) => setDepositAmount(event.target.value)} inputMode="decimal" />
                </label>
                <label>
                  {t.agent.strategyRoute}
                  <select value={selectedStrategy} onChange={(event) => setSelectedStrategy(event.target.value)}>
                    {(vault?.strategies || []).map((strategy) => (
                      <option value={strategy.id} key={strategy.id}>
                        {strategy.name}
                      </option>
                    ))}
                  </select>
                </label>
                <button className="primary-button full" type="button" onClick={runDeposit}>
                  {t.agent.mockDeposit}
                </button>
              </article>

              <article className="funding-form">
                <h3>{t.agent.withdrawTitle}</h3>
                <label>
                  {t.agent.amount}
                  <input value={withdrawAmount} onChange={(event) => setWithdrawAmount(event.target.value)} inputMode="decimal" />
                </label>
                <label>
                  {t.agent.maxDailyLoss}
                  <input value={vault?.maxDailyLoss || "3.0%"} readOnly />
                </label>
                <button className="secondary-button blue full" type="button" onClick={runWithdraw}>
                  {t.agent.requestWithdraw}
                </button>
              </article>
            </div>
          </section>

          <section className="strategy-grid">
            {(vault?.strategies || []).map((strategy) => (
              <article className="strategy-card glass-panel" key={strategy.id}>
                <div className="strategy-head">
                  <div>
                    <span>{strategy.type}</span>
                    <h3>{strategy.name}</h3>
                  </div>
                  <strong>{strategy.status}</strong>
                </div>
                <p>{strategy.target}</p>
                <div className="strategy-meta">
                  <span>
                    {t.agent.risk} <strong>{strategy.risk}</strong>
                  </span>
                  <span>
                    {t.agent.allocated} <strong>{formatBnb(strategy.allocation)}</strong>
                  </span>
                  <span>
                    {t.agent.mockPnl} <strong className="pnl-positive">{strategy.pnl}</strong>
                  </span>
                </div>
                <label>
                  {t.agent.allocation}
                  <input value={allocationAmount} onChange={(event) => setAllocationAmount(event.target.value)} inputMode="decimal" />
                </label>
                <button className="secondary-button full" type="button" onClick={() => launchStrategy(strategy.id)}>
                  {t.agent.queueStrategy}
                </button>
              </article>
            ))}
          </section>
        </main>

        <aside className="agent-side-stack">
          <section className="chat-panel glass-panel agent-chat">
            <div className="chat-header">
              <span className="eyebrow">{t.agent.agentChat}</span>
              <h3>{activeAgent}</h3>
            </div>
            <div className="messages">
              {messages.map((message, index) => (
                <div className={`message ${message.role}`} key={`${message.role}-${index}`}>
                  {message.text}
                </div>
              ))}
              {loading ? <div className="message ai loading">{t.agent.thinking}</div> : null}
            </div>
            <div className="chat-input">
              <input
                value={input}
                onChange={(event) => setInput(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter") send();
                }}
                placeholder={t.agent.placeholder}
              />
              <button className="primary-button" type="button" onClick={send}>
                {t.agent.send}
              </button>
            </div>
          </section>

          <section className="activity-feed glass-panel">
            <div className="panel-split-head">
              <h3>{t.agent.executionLog}</h3>
              <span>{actionStatus}</span>
            </div>
            {(vault?.activity || []).map((item) => (
              <article key={`${item.time}-${item.action}`}>
                <time>{item.time}</time>
                <strong>{item.action}</strong>
                <span>{item.result}</span>
              </article>
            ))}
          </section>
        </aside>
      </div>

      <article className="risk-note agent-risk-note">
        <strong>{t.agent.riskDisclosure}</strong>
        <p>{vault?.disclaimer}</p>
      </article>
    </section>
  );
}
