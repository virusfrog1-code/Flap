const BSC_CHAIN_ID = 56;
const BSC_RPC = "https://bsc-dataseed.binance.org/";
const BABYX_TOKEN = "0xe1734a27f06f1189b0f65ae3b68fc010d4717777";
const BABYX_NFT = "0xAACCa5fAa8CA6be637cD346EC1e7CcDbfD819ae0";
const BABYX_VAULT = "0x2c74c503b1BE8A8E23aB6aeDBc6F5935b34EAA78";
const MARKETPLACE_STORAGE_KEY = "babyx_marketplace_address";

const ERC20_ABI = [
  "function name() view returns (string)",
  "function symbol() view returns (string)",
  "function decimals() view returns (uint8)",
  "function totalSupply() view returns (uint256)",
  "function balanceOf(address) view returns (uint256)"
];

const ERC721_ABI = [
  "function supportsInterface(bytes4 interfaceId) view returns (bool)",
  "function name() view returns (string)",
  "function symbol() view returns (string)",
  "function totalSupply() view returns (uint256)",
  "function balanceOf(address) view returns (uint256)",
  "function ownerOf(uint256 tokenId) view returns (address)",
  "function tokenURI(uint256 tokenId) view returns (string)",
  "function approve(address to,uint256 tokenId)",
  "function getApproved(uint256 tokenId) view returns (address)",
  "function setApprovalForAll(address operator,bool approved)",
  "function isApprovedForAll(address owner,address operator) view returns (bool)"
];

const MARKETPLACE_ABI = [
  "function list(address nft,uint256 tokenId,uint256 priceWei)",
  "function cancel(uint256 listingId)",
  "function buy(uint256 listingId) payable",
  "function nextListingId() view returns (uint256)",
  "function listings(uint256 listingId) view returns (address seller,address nft,uint256 tokenId,uint256 priceWei,bool active)"
];

const provider = new ethers.JsonRpcProvider(BSC_RPC);
let walletProvider;
let signer;
let walletAddress = "";
let marketplaceAddress = localStorage.getItem(MARKETPLACE_STORAGE_KEY) || "";
let chainCollections = [];
let marketplaceListings = [];

const listings = [
  { id: 1, collection: "BabyX NFA", price: "TBA", rarity: "Genesis", theme: "gold", sticker: "GENESIS", icon: "NFA", traits: ["Rocket Pack", "Baby Helmet", "BNB Gold"], nft: BABYX_NFT },
  { id: 7, collection: "BabyX NFA", price: "TBA", rarity: "Rare", theme: "mint", sticker: "VPN NODE", icon: "VPN", traits: ["VPN Antenna", "Signal Halo", "GM"], nft: BABYX_NFT },
  { id: 18, collection: "BabyX NFA", price: "TBA", rarity: "Epic", theme: "blue", sticker: "WEN MOON", icon: "GM", traits: ["Orbit Rings", "Moon Cap", "WEN MOON"], nft: BABYX_NFT },
  { id: 44, collection: "BabyX NFA", price: "TBA", rarity: "Rare", theme: "red", sticker: "SAFU", icon: "4", traits: ["Mars Booster", "Laser Pacifier", "SAFU"], nft: BABYX_NFT },
  { id: 88, collection: "BabyX NFA", price: "TBA", rarity: "Common", theme: "black", sticker: "4", icon: "BNB", traits: ["Rocket Pack", "BNB Collar", "4"], nft: BABYX_NFT },
  { id: 128, collection: "BabyX NFA", price: "TBA", rarity: "Epic", theme: "violet", sticker: "NO LAG", icon: "AI", traits: ["VPN Antenna", "Diamond Paws", "No Lag"], nft: BABYX_NFT },
  { id: 404, collection: "BabyX NFA", price: "TBA", rarity: "Legendary", theme: "chrome", sticker: "BABY SIGNAL", icon: "SIG", traits: ["Signal Wings", "Moon Surface", "Baby Signal"], nft: BABYX_NFT },
  { id: 666, collection: "BabyX NFA", price: "TBA", rarity: "Legendary", theme: "orange", sticker: "FREE SIGNAL", icon: "X", traits: ["Orbit Launch", "Gold Helmet", "Free Signal"], nft: BABYX_NFT }
];

const externalVaults = [];
const rarityRank = { Legendary: 0, Genesis: 1, Epic: 2, Rare: 3, Common: 4, "On-chain": 5, "Flap Vault": 6 };

function shortAddress(address) {
  if (!address || address.length < 12) return address || "";
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}

function setText(selector, value) {
  const el = document.querySelector(selector);
  if (el) el.textContent = value;
}

function validAddress(value) {
  return /^0x[a-fA-F0-9]{40}$/.test(value || "");
}

async function safeCall(contract, fn, fallback = null) {
  try {
    return await contract[fn]();
  } catch {
    return fallback;
  }
}

async function readToken(address) {
  const token = new ethers.Contract(address, ERC20_ABI, provider);
  const [name, symbol, decimals, totalSupply] = await Promise.all([
    safeCall(token, "name", "Unknown Token"),
    safeCall(token, "symbol", "TOKEN"),
    safeCall(token, "decimals", 18),
    safeCall(token, "totalSupply", 0n)
  ]);
  return {
    type: "Token",
    address,
    name,
    symbol,
    totalSupply: ethers.formatUnits(totalSupply, Number(decimals)),
    decimals: Number(decimals)
  };
}

async function readNft(address) {
  const nft = new ethers.Contract(address, ERC721_ABI, provider);
  let isErc721 = false;
  try {
    isErc721 = await nft.supportsInterface("0x80ac58cd");
  } catch {
    isErc721 = false;
  }
  const [name, symbol, totalSupply] = await Promise.all([
    safeCall(nft, "name", "Unknown NFT"),
    safeCall(nft, "symbol", "NFT"),
    safeCall(nft, "totalSupply", 0n)
  ]);
  return {
    type: "NFT",
    address,
    name,
    symbol,
    totalSupply: totalSupply ? totalSupply.toString() : "0",
    isErc721
  };
}

async function detectKnownFlapProject(address) {
  const lower = address.toLowerCase();
  if ([BABYX_TOKEN, BABYX_NFT, BABYX_VAULT].some((item) => item.toLowerCase() === lower)) {
    const [token, nft] = await Promise.all([readToken(BABYX_TOKEN), readNft(BABYX_NFT)]);
    return {
      collection: "BabyX NFA",
      token,
      nft,
      vault: BABYX_VAULT,
      supply: "666",
      sourceLabel: "已识别 BabyX Flap Vault"
    };
  }
  return null;
}

async function detectGenericProject(address) {
  const nft = await readNft(address);
  if (nft.isErc721) {
    return {
      collection: nft.name || `Flap NFT ${shortAddress(address)}`,
      nft,
      token: null,
      vault: address,
      supply: nft.totalSupply || "Unknown",
      sourceLabel: "已按 NFT 合约接入"
    };
  }
  const token = await readToken(address);
  return {
    collection: token.name || `Flap Token ${shortAddress(address)}`,
    token,
    nft: null,
    vault: address,
    supply: "Unknown",
    sourceLabel: "已按 Token 合约接入"
  };
}

function marketArt(item) {
  return `
    <div class="nft-art nft-art-${item.theme}">
      <div class="art-orbit"></div>
      <div class="art-chip">${item.sticker}</div>
      <div class="art-icon">${item.icon}</div>
      <img src="./assets/babyx-nfa-butterfly-space-512.jpg" alt="${item.collection} #${String(item.id).padStart(4, "0")}" loading="lazy" />
      <div class="art-number">#${String(item.id).padStart(4, "0")}</div>
      <div class="art-rarity">${item.rarity}</div>
    </div>
  `;
}

function renderMarket() {
  const grid = document.querySelector("#marketGrid");
  const search = document.querySelector("#marketSearch");
  const sort = document.querySelector("#marketSort");
  if (!grid) return;

  const query = (search?.value || "").trim().toLowerCase();
  const sortValue = sort?.value || "id";
  const allListings = [...marketplaceListings, ...externalVaults, ...listings];

  const filtered = allListings
    .filter((item) => {
      const text = `#${item.id} ${item.collection} ${item.rarity} ${item.sticker} ${item.traits.join(" ")}`.toLowerCase();
      return text.includes(query);
    })
    .sort((a, b) => {
      if (sortValue === "rarity") return (rarityRank[a.rarity] ?? 9) - (rarityRank[b.rarity] ?? 9);
      if (sortValue === "price") return a.id - b.id;
      return a.id - b.id;
    });

  grid.innerHTML = filtered
    .map((item) => {
      const canList = marketplaceAddress && walletAddress && item.nft && item.id <= 666 && item.source !== "market";
      const canBuy = marketplaceAddress && walletAddress && item.source === "market" && item.listingId;
      return `
        <article class="market-card market-card-${item.theme}">
          ${marketArt(item)}
          <div class="market-card-body">
            <div class="market-card-title">
              <strong>${item.collection} #${String(item.id).padStart(4, "0")}</strong>
              <span>${item.rarity}</span>
            </div>
            <div class="trait-row">${item.traits.map((trait) => `<b>${trait}</b>`).join("")}</div>
            <div class="market-card-bottom">
              <span>${item.price}</span>
              <button type="button" data-action="${canBuy ? "buy" : "list"}" data-listing-id="${item.listingId || ""}" data-price-wei="${item.priceWei || ""}" data-nft="${item.nft || ""}" data-token-id="${item.id}" ${canList || canBuy ? "" : "disabled"}>
                ${canBuy ? "购买" : marketplaceAddress ? "挂单" : "先部署市场"}
              </button>
            </div>
          </div>
        </article>
      `;
    })
    .join("");

  setText("#listedCount", String(allListings.length));
  setText("#vaultCount", String(1 + externalVaults.length));
}

async function detectVault() {
  const input = document.querySelector("#vaultAddressInput");
  const status = document.querySelector("#vaultDetectStatus");
  const address = (input?.value || "").trim();
  if (!validAddress(address)) {
    status.textContent = "请输入有效的 0x 合约地址。可以是 Flap 的 Token、NFT 或 Vault 地址。";
    return;
  }
  if (externalVaults.some((item) => item.address.toLowerCase() === address.toLowerCase())) {
    status.textContent = `这个 Flap 项目已经在市场列表中：${shortAddress(address)}`;
    return;
  }

  status.textContent = "正在从 BSC 读取合约信息...";
  try {
    const project = (await detectKnownFlapProject(address)) || (await detectGenericProject(address));
    externalVaults.unshift({
      id: 900 + externalVaults.length,
      collection: project.collection,
      price: "On-chain",
      rarity: "On-chain",
      theme: "chrome",
      sticker: project.token?.symbol || project.nft?.symbol || "FLAP",
      icon: "LIVE",
      traits: [
        project.sourceLabel,
        project.nft ? `NFT ${shortAddress(project.nft.address)}` : "NFT 待识别",
        project.token ? `Token ${shortAddress(project.token.address)}` : "Token 待识别"
      ],
      address,
      nft: project.nft?.address || "",
      source: "external"
    });
    status.textContent = `${project.sourceLabel}：${project.collection}，Supply ${project.supply}。`;
    input.value = "";
    renderMarket();
  } catch (error) {
    status.textContent = `读取失败：${error?.shortMessage || error?.message || error}`;
  }
}

async function syncBabyXChain() {
  const status = document.querySelector("#marketChainStatus");
  status.textContent = "正在读取 BabyX Token / NFT / Vault 链上数据...";
  try {
    const [token, nft] = await Promise.all([readToken(BABYX_TOKEN), readNft(BABYX_NFT)]);
    if (marketplaceAddress && validAddress(marketplaceAddress)) {
      await loadMarketplaceListings();
    }
    renderMarket();
    status.textContent = `链上已同步：${token.symbol} 总量 ${Number(token.totalSupply).toLocaleString()}，NFT ${nft.symbol} 已铸造 ${nft.totalSupply}。Vault ${shortAddress(BABYX_VAULT)}。`;
  } catch (error) {
    status.textContent = `链上读取失败：${error?.shortMessage || error?.message || error}`;
  }
}

async function loadMarketplaceListings() {
  if (!marketplaceAddress || !validAddress(marketplaceAddress)) return;
  const market = new ethers.Contract(marketplaceAddress, MARKETPLACE_ABI, provider);
  const next = Number(await market.nextListingId());
  const max = Math.min(next, 60);
  const loaded = [];
  for (let id = 1; id < max; id += 1) {
    try {
      const item = await market.listings(id);
      if (!item.active) continue;
      loaded.push({
        id: Number(item.tokenId),
        listingId: id,
        collection: item.nft.toLowerCase() === BABYX_NFT.toLowerCase() ? "BabyX NFA" : `NFT ${shortAddress(item.nft)}`,
        price: `${ethers.formatEther(item.priceWei)} BNB`,
        priceWei: item.priceWei.toString(),
        rarity: "On-chain",
        theme: "mint",
        sticker: "LIVE LISTING",
        icon: "BUY",
        traits: [`Seller ${shortAddress(item.seller)}`, `NFT ${shortAddress(item.nft)}`, `Listing #${id}`],
        nft: item.nft,
        source: "market"
      });
    } catch {
      // Skip malformed listing slots.
    }
  }
  marketplaceListings = loaded;
}

async function connectWallet() {
  const status = document.querySelector("#marketChainStatus");
  if (!window.ethereum) {
    status.textContent = "未检测到钱包，请用安装 MetaMask / OKX Wallet 的浏览器打开。";
    return;
  }
  walletProvider = new ethers.BrowserProvider(window.ethereum);
  const network = await walletProvider.getNetwork();
  if (Number(network.chainId) !== BSC_CHAIN_ID) {
    await window.ethereum.request({ method: "wallet_switchEthereumChain", params: [{ chainId: "0x38" }] });
  }
  signer = await walletProvider.getSigner();
  walletAddress = await signer.getAddress();
  status.textContent = `钱包已连接：${shortAddress(walletAddress)}。`;
  renderMarket();
}

function saveMarketplaceAddress() {
  const input = document.querySelector("#marketplaceAddressInput");
  const value = (input?.value || "").trim();
  const status = document.querySelector("#marketChainStatus");
  if (!validAddress(value)) {
    status.textContent = "请输入有效的 Marketplace 合约地址。";
    return;
  }
  marketplaceAddress = value;
  localStorage.setItem(MARKETPLACE_STORAGE_KEY, value);
  status.textContent = `Marketplace 已保存：${shortAddress(value)}。现在可以连接钱包后挂单。`;
  loadMarketplaceListings().then(renderMarket).catch(() => renderMarket());
  renderMarket();
}

async function listNft(nftAddress, tokenId) {
  const status = document.querySelector("#marketChainStatus");
  if (!marketplaceAddress) {
    status.textContent = "请先部署并保存 Marketplace 合约地址。";
    return;
  }
  if (!signer) await connectWallet();
  const price = prompt("请输入挂单价格，单位 BNB", "0.1");
  if (!price) return;
  try {
    const nft = new ethers.Contract(nftAddress, ERC721_ABI, signer);
    const market = new ethers.Contract(marketplaceAddress, MARKETPLACE_ABI, signer);
    status.textContent = "正在授权 NFT 给 Marketplace...";
    const owner = await nft.ownerOf(tokenId);
    if (owner.toLowerCase() !== walletAddress.toLowerCase()) {
      status.textContent = `这个 NFT 当前不在你的钱包：owner ${shortAddress(owner)}`;
      return;
    }
    const approved = await nft.getApproved(tokenId);
    if (approved.toLowerCase() !== marketplaceAddress.toLowerCase()) {
      const approveTx = await nft.approve(marketplaceAddress, tokenId);
      await approveTx.wait();
    }
    status.textContent = "正在提交挂单交易...";
    const tx = await market.list(nftAddress, tokenId, ethers.parseEther(price));
    await tx.wait();
    status.textContent = `挂单完成：${price} BNB，NFT #${tokenId}。`;
    await loadMarketplaceListings();
    renderMarket();
  } catch (error) {
    status.textContent = `挂单失败：${error?.shortMessage || error?.message || error}`;
  }
}

async function buyNft(listingId, priceWei) {
  const status = document.querySelector("#marketChainStatus");
  if (!marketplaceAddress) {
    status.textContent = "请先保存 Marketplace 合约地址。";
    return;
  }
  if (!signer) await connectWallet();
  try {
    const market = new ethers.Contract(marketplaceAddress, MARKETPLACE_ABI, signer);
    status.textContent = `正在购买 Listing #${listingId}...`;
    const tx = await market.buy(listingId, { value: BigInt(priceWei) });
    await tx.wait();
    status.textContent = `购买完成：Listing #${listingId}。`;
    await loadMarketplaceListings();
    renderMarket();
  } catch (error) {
    status.textContent = `购买失败：${error?.shortMessage || error?.message || error}`;
  }
}

function hydrateMarketplaceInput() {
  const input = document.querySelector("#marketplaceAddressInput");
  if (input && marketplaceAddress) input.value = marketplaceAddress;
}

window.addEventListener("DOMContentLoaded", () => {
  hydrateMarketplaceInput();
  renderMarket();
  syncBabyXChain();
  document.querySelector("#marketSearch")?.addEventListener("input", renderMarket);
  document.querySelector("#marketSort")?.addEventListener("change", renderMarket);
  document.querySelector("#detectVaultButton")?.addEventListener("click", detectVault);
  document.querySelector("#connectMarketWalletButton")?.addEventListener("click", connectWallet);
  document.querySelector("#syncChainButton")?.addEventListener("click", syncBabyXChain);
  document.querySelector("#saveMarketplaceButton")?.addEventListener("click", saveMarketplaceAddress);
  document.querySelector("#marketGrid")?.addEventListener("click", (event) => {
    const button = event.target.closest("button[data-action='list']");
    if (button) {
      listNft(button.dataset.nft, Number(button.dataset.tokenId));
      return;
    }
    const buyButton = event.target.closest("button[data-action='buy']");
    if (buyButton) {
      buyNft(Number(buyButton.dataset.listingId), buyButton.dataset.priceWei);
    }
  });

  if (window.lucide) {
    window.lucide.createIcons();
  }
});
