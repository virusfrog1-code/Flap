// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IERC721Minimal {
    function ownerOf(uint256 tokenId) external view returns (address);
    function transferFrom(address from, address to, uint256 tokenId) external;
}

contract BabyXNfaMarketplace {
    struct Listing {
        address seller;
        address nft;
        uint256 tokenId;
        uint256 priceWei;
        bool active;
    }

    address public owner;
    address public feeRecipient;
    uint256 public feeBps;
    uint256 public nextListingId = 1;
    mapping(uint256 => Listing) public listings;

    event Listed(uint256 indexed listingId, address indexed seller, address indexed nft, uint256 tokenId, uint256 priceWei);
    event Cancelled(uint256 indexed listingId);
    event Bought(uint256 indexed listingId, address indexed buyer, uint256 priceWei);
    event FeeUpdated(address indexed feeRecipient, uint256 feeBps);

    modifier onlyOwner() {
        require(msg.sender == owner, "NOT_OWNER");
        _;
    }

    constructor(address _feeRecipient, uint256 _feeBps) {
        require(_feeBps <= 1000, "FEE_TOO_HIGH");
        owner = msg.sender;
        feeRecipient = _feeRecipient == address(0) ? msg.sender : _feeRecipient;
        feeBps = _feeBps;
    }

    function list(address nft, uint256 tokenId, uint256 priceWei) external {
        require(priceWei > 0, "PRICE_ZERO");
        IERC721Minimal token = IERC721Minimal(nft);
        require(token.ownerOf(tokenId) == msg.sender, "NOT_TOKEN_OWNER");
        token.transferFrom(msg.sender, address(this), tokenId);

        uint256 listingId = nextListingId++;
        listings[listingId] = Listing({
            seller: msg.sender,
            nft: nft,
            tokenId: tokenId,
            priceWei: priceWei,
            active: true
        });
        emit Listed(listingId, msg.sender, nft, tokenId, priceWei);
    }

    function cancel(uint256 listingId) external {
        Listing storage item = listings[listingId];
        require(item.active, "NOT_ACTIVE");
        require(msg.sender == item.seller || msg.sender == owner, "NOT_SELLER");
        item.active = false;
        IERC721Minimal(item.nft).transferFrom(address(this), item.seller, item.tokenId);
        emit Cancelled(listingId);
    }

    function buy(uint256 listingId) external payable {
        Listing storage item = listings[listingId];
        require(item.active, "NOT_ACTIVE");
        require(msg.value == item.priceWei, "WRONG_VALUE");
        item.active = false;

        uint256 fee = (msg.value * feeBps) / 10000;
        uint256 sellerAmount = msg.value - fee;
        if (fee > 0) {
            (bool feeOk, ) = payable(feeRecipient).call{value: fee}("");
            require(feeOk, "FEE_TRANSFER_FAILED");
        }
        (bool sellerOk, ) = payable(item.seller).call{value: sellerAmount}("");
        require(sellerOk, "SELLER_TRANSFER_FAILED");

        IERC721Minimal(item.nft).transferFrom(address(this), msg.sender, item.tokenId);
        emit Bought(listingId, msg.sender, msg.value);
    }

    function setFee(address _feeRecipient, uint256 _feeBps) external onlyOwner {
        require(_feeRecipient != address(0), "ZERO_RECIPIENT");
        require(_feeBps <= 1000, "FEE_TOO_HIGH");
        feeRecipient = _feeRecipient;
        feeBps = _feeBps;
        emit FeeUpdated(_feeRecipient, _feeBps);
    }
}
