// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IPixelArtSchemaImage {
    function schemaVersion() external view returns (uint256);
    function schemaName() external view returns (string memory);
    function canvas(uint256 seed, uint256 tokenId) external view returns (string memory svgFragment);
}

contract BabyXNFAImageSchema is IPixelArtSchemaImage {
    string private constant ARTWORK_URL = "https://v0-gitbook-two.vercel.app/assets/babyx-nfa-butterfly-space-animated.svg?v=12";

    function schemaVersion() external pure returns (uint256) {
        return 9;
    }

    function schemaName() external pure returns (string memory) {
        return "BabyX NFA Flap Quick Dynamic";
    }

    function canvas(uint256, uint256 tokenId) external pure returns (string memory svgFragment) {
        string memory idText = _toString(tokenId);

        return string.concat(
            "<defs>",
            '<clipPath id="babyxExactClip"><rect x="18" y="18" width="476" height="476" rx="28"/></clipPath>',
            '<path id="babyxExactBorder" d="M 48 34 L 464 34 A 18 18 0 0 1 482 52 L 482 464 A 18 18 0 0 1 464 482 L 48 482 A 18 18 0 0 1 30 464 L 30 52 A 18 18 0 0 1 48 34 Z" fill="none"/>',
            "</defs>",
            '<g id="babyx-nfa-exact-dynamic">',
            '<rect width="512" height="512" rx="30" fill="#050509"/>',
            '<g clip-path="url(#babyxExactClip)">',
            '<image href="', ARTWORK_URL, '" x="18" y="18" width="476" height="476" preserveAspectRatio="xMidYMid slice"/>',
            "</g>",
            '<rect x="18" y="18" width="476" height="476" rx="28" fill="none" stroke="#050509" stroke-width="14"/>',
            '<rect x="27" y="27" width="458" height="458" rx="24" fill="none" stroke="#f3ba2f" stroke-width="4" opacity=".9"/>',
            '<rect x="38" y="36" width="132" height="34" rx="17" fill="#fff"/>',
            '<text x="104" y="58" font-family="Arial, sans-serif" font-size="13" font-weight="900" fill="#111" text-anchor="middle">BABYX</text>',
            '<rect x="370" y="36" width="82" height="34" rx="17" fill="#dff2ff"/>',
            '<text x="411" y="58" font-family="Arial, sans-serif" font-size="13" font-weight="900" fill="#111" text-anchor="middle">NFA</text>',
            '<rect x="213" y="430" width="86" height="30" rx="15" fill="#050505" opacity=".76"/>',
            '<text x="256" y="451" font-family="Arial, sans-serif" font-size="17" font-weight="900" fill="#fff" text-anchor="middle">#',
            idText,
            "</text>",
            _marquee(),
            "</g>"
        );
    }

    function _marquee() internal pure returns (string memory) {
        return string.concat(
            "<text text-rendering='optimizeSpeed' xml:space='preserve'>",
            "<textPath startOffset='-90%' fill='white' font-family='Courier New, monospace' font-size='9px' letter-spacing='2' href='#babyxExactBorder' xlink:href='#babyxExactBorder'>BABYX NFA BUTTERFLY SPACE SIGNAL ",
            "<animate additive='sum' attributeName='startOffset' from='0%' to='100%' begin='0s' dur='30s' repeatCount='indefinite'/></textPath>",
            "<textPath startOffset='10%' fill='white' font-family='Courier New, monospace' font-size='9px' letter-spacing='2' href='#babyxExactBorder' xlink:href='#babyxExactBorder'>BABYX NFA BUTTERFLY SPACE SIGNAL ",
            "<animate additive='sum' attributeName='startOffset' from='0%' to='100%' begin='0s' dur='30s' repeatCount='indefinite'/></textPath>",
            "</text>"
        );
    }

    function _toString(uint256 value) internal pure returns (string memory) {
        if (value == 0) return "0";
        uint256 temp = value;
        uint256 digits;
        while (temp != 0) {
            digits++;
            temp /= 10;
        }
        bytes memory buffer = new bytes(digits);
        while (value != 0) {
            digits -= 1;
            buffer[digits] = bytes1(uint8(48 + uint256(value % 10)));
            value /= 10;
        }
        return string(buffer);
    }
}
