// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IPixelArtSchema {
    function schemaVersion() external view returns (uint256);
    function schemaName() external view returns (string memory);
    function canvas(uint256 seed, uint256 tokenId) external view returns (string memory svgFragment);
}

contract BabyXNFASchema is IPixelArtSchema {
    string[6] private palettes = ["#f3ba2f", "#35e987", "#69d2ff", "#ff6d5f", "#9b7cff", "#d9f1ff"];
    string[6] private suits = ["#101010", "#0f5132", "#173e8a", "#8a1d29", "#40258f", "#5c6b73"];
    string[6] private stickers = ["WEN MOON", "BABYX", "SAFU", "GM", "4", "NFA"];
    string[4] private gears = ["ROCKET", "VPN", "ORBIT", "AGENT"];

    function schemaVersion() external pure returns (uint256) {
        return 1;
    }

    function schemaName() external pure returns (string memory) {
        return "BabyX NFA Schema";
    }

    function canvas(uint256 seed, uint256 tokenId) external view returns (string memory svgFragment) {
        uint256 r = uint256(keccak256(abi.encodePacked(seed, tokenId)));
        string memory accent = palettes[r % palettes.length];
        string memory suit = suits[(r >> 8) % suits.length];
        string memory sticker = stickers[(r >> 16) % stickers.length];
        string memory gear = gears[(r >> 24) % gears.length];
        string memory idText = string.concat("#", _toString(tokenId));

        string memory top = string.concat(
            '<rect width="100%" height="100%" rx="24" fill="#090909"/>',
            '<circle cx="420" cy="90" r="58" fill="', accent, '" opacity="0.35"/>',
            '<ellipse cx="250" cy="260" rx="210" ry="72" transform="rotate(-22 250 260)" fill="none" stroke="', accent, '" stroke-width="10" opacity="0.8"/>'
        );

        string memory labels = string.concat(
            '<rect x="34" y="32" width="170" height="44" rx="22" fill="#fff"/>',
            '<text x="119" y="61" font-family="Arial" font-size="18" font-weight="900" fill="#111" text-anchor="middle">', sticker, '</text>',
            '<rect x="334" y="34" width="126" height="42" rx="21" fill="', accent, '"/>',
            '<text x="397" y="62" font-family="Arial" font-size="17" font-weight="900" fill="#111" text-anchor="middle">', gear, '</text>'
        );

        string memory body = string.concat(
            '<path d="M118 470 V360 C118 312 160 288 250 288 C340 288 382 312 382 360 V470 Z" fill="', suit, '"/>',
            '<circle cx="250" cy="344" r="46" fill="', accent, '"/>',
            '<circle cx="250" cy="344" r="25" fill="#111"/>',
            '<circle cx="250" cy="232" r="150" fill="', suit, '"/>',
            '<circle cx="250" cy="232" r="130" fill="#f7fdff"/>'
        );

        string memory head = string.concat(
            '<path d="M146 238 C134 164 164 108 206 122 C224 98 276 98 294 122 C336 108 366 164 354 238 C344 314 296 344 250 344 C204 344 156 314 146 238 Z" fill="#f4a64f"/>',
            '<path d="M174 156 L196 247 L235 180 Z M326 156 L304 247 L265 180 Z" fill="#ffdca8"/>',
            '<ellipse cx="250" cy="278" rx="70" ry="54" fill="#ffd39b"/>',
            '<ellipse cx="210" cy="246" rx="14" ry="18" fill="#111"/>',
            '<ellipse cx="290" cy="246" rx="14" ry="18" fill="#111"/>',
            '<circle cx="215" cy="240" r="4" fill="#fff"/>',
            '<circle cx="295" cy="240" r="4" fill="#fff"/>',
            '<rect x="226" y="272" width="48" height="30" rx="15" fill="#ffe4ef" stroke="#111" stroke-width="7"/>',
            '<circle cx="250" cy="287" r="7" fill="#111"/>'
        );

        string memory glass = string.concat(
            '<circle cx="250" cy="232" r="123" fill="#ffffff" opacity="0.22"/>',
            '<circle cx="250" cy="232" r="127" fill="none" stroke="#fff" stroke-width="7" opacity="0.82"/>',
            '<text x="45" y="450" font-family="Arial" font-size="48" font-weight="900" fill="#fff" opacity="0.24">4</text>',
            '<text x="380" y="450" font-family="Arial" font-size="38" font-weight="900" fill="#fff" opacity="0.24">GM</text>',
            '<text x="250" y="438" font-family="Arial" font-size="22" font-weight="900" fill="#fff" text-anchor="middle">', idText, '</text>'
        );

        return string.concat('<g id="babyx-nfa">', top, labels, body, head, glass, '</g>');
    }

    function _toString(uint256 value) internal pure returns (string memory) {
        if (value == 0) return "0";
        uint256 temp = value;
        uint256 digits;
        while (temp != 0) {
            digits++;
            temp /= 10;
        }
        bytes memory buffer = new bytes(digits);
        while (value != 0) {
            digits -= 1;
            buffer[digits] = bytes1(uint8(48 + uint256(value % 10)));
            value /= 10;
        }
        return string(buffer);
    }
}
